
CONTENTS

This directory contains the Brown Corpus, in Form C (tagged).  Each
filename consists of a "c" (corpus form C), followed by a letter a-r
designating the genre, followed by two digits.

A. PRESS: REPORTAGE
B. PRESS: EDITORIAL
C. PRESS: REVIEWS
D. RELIGION
E. SKILL AND HOBBIES
F. POPULAR LORE
G. BELLES-LETTRES
H. MISCELLANEOUS: GOVERNMENT & HOUSE ORGANS
J. LEARNED
K: FICTION: GENERAL
L: FICTION: MYSTERY
M: FICTION: SCIENCE
N: FICTION: ADVENTURE
P. FICTION: ROMANCE
R. HUMOR



LIST OF TEXTS

A. PRESS: REPORTAGE

A01. The Atlanta Constitution
        	Used by permission of The Atlanta Constitution
        	State News Service (H), and Reg Murphy (E).
	A. November 4, 1961, p.1	"Atlanta Primary ..."	0010-0670
	B.                      	"Hartsfield Files"	0680-0850
	C. August 17, 1961,  p.6        "Urged strongly ..."	0860-1060
	D.	                        "Sam Caldwell Joins"	1070-1130
	E. March 6,1961,     p.1	"Legislators Are Moving" 
                                          by Reg Murphy 	1140-1390
	F.                        	Legislator to fight" 
                                        by Richard Ashworth	1400-1530
	G.	                        "House Due Bid..."	1530-1670
	H.                   p.18	"Harry Miller Wins..."	1670-1920
Arbitrary Hyphen: multi-million [0520]
1,988 words	431 (21.7%) quotes 2 symbols

A02. The Dallas Morning News, February 17,1961,section 1
        	Used by permission of The Dallas Morning News
	A.                   p.5       "Committee OK ... " 
                                          by Jimmy Banks	0010-0360
	B.	                       "Austin Wire ... " 
                                        by Dawson Duncan	0370-0990
	C.	                       "Legislator Reject ... "	1000-1140
	D.	                       "Water Development" 
                                        by Richard M. Morehead	1150-1360
	E.	                       "Cut proposed ... "	1370-1520
	F.                   p.12      "Paris College ... "	1530-1700
	G.	                       "Principals ... "	1710-1740
	    Chicago Daily Tribune, February 10, 1961, part 1, p.4
	    Used by permission of Chicago Daily Tribune
	H.                             "Report on ADC ... "	1750-1970
Typographical Error: county [0730]
2,015 words	181 (9.0 %) quotes 11 symbols

A03. Chicago Daily Tribune
        	Used by permission of Chicago Daily Tribune
	A. July 25, 1961,	p.1    "Cops'Defense"   	0010-0190
	                      		 by Robert Wiedrich
	B.		               "Kennedy Busy ... " 
                                         by Robert Young	0200-0360
	C.		               "Dismisses All ..."	0370-0740
	D. February 10, 1961,	p.1    "Kennedy's Aged" 
                                         by Laurence Burd	0750-1760
	E.		               "Senate OK's ..."	1770-1890
Typographical Error:	word missing [0840]
2,024 words	305 (15.1%] quotes


A04. The Christian Science Monitor, May 11,1961, p.1
        	Used by permission of The Christian Science Monitor
	A.		               "NATO Welds Unity" 
                                         by Courtney Sheldon	0010-0710
	B.		               "Kennedey tried ..." 
                                         by Joan Thiriet	0720-1720
	C.		               "Kennedy Hits ..."	1730-1960
	Typographical Errors:	conspicious [0150] ot [for to] [1900]
			                           ond [for and] [1930]
2,020 words	186 (9.2%) quotes 13 symbols

A05. The Providence Journal
        	Used by permission of The Providence Journal
	A. July 23, 1961, p.19	       "Full-Time CD Chief..."	0010-0470 
			                 by William J. Thompson 
	B. July 16, 1961, sec. 1, p.9  	"Notte Proposes Study"	0480-0920
	C. Juy 19, 1961, p.5	       "2 New Party Alignments"	0930-1220
	D. July 20, 1961, p.5	       "Johnston Home Rule"	1230-1720
	E. Juy 22, 1961, p.17	       "N. Providence May..."	1730-1850
Typographical Error:	. for ,[0210]
2,034 words	303 (14.9%) quotes 7 symbols

A06. Newark Evening News, March 22, 1961, p.25
        	Used by permission of Newark Evening News
	A.		               "Mitchell Replies.." 
                                         by Bruce Bahrenburg	0010-0900
	B.		               "Paper Ballot End Sought"0910-1030
	C.		               "Sheeran Backed by Roos"	1040-1150
	D.		               "Fire Warden Ends Career"1160-1320
	E.		               "Hughes in Morris Debut" 
			                by John L. Cavnar 	1330-1790
	F.		               "GOP Group Honors 15"	1800-1920
Arbitrary Hyphen:	peace-loving [0620]
Typographical Errors:	adminstration [0250]
		        Nothing [for Noting] [0410]
		        alloted [1680]
2,005 words	760 (37.9%) quotes 8 symbols

A07. The New York Times, June 19, 1961, p.1
	Copyright 1961 by The New York Times Company. Reprinted by permission
	A.		               "Wagner Attempt" 
                                         by Leo Egan	        0010-0480
	B.		               "Massachusetts ..." 
                                         by Anthony Lewis	0490-0720
	C.		               "House Foes Plan" 
                                         by David Halberstam	0730-1040
	D.		               "Peace Corps Ties"  
                                         by John Wicklein	1050-1330
	E.		               "Red Bloc Spurs Aid" 
                                         by Seymor Topping	1340-1470
	F.		               "Population Urged ..." 
                                         by Robert Conley	1480-1710
	G.		               "3 Princes of Laos" 
                                         by Drew Middleton	1720-1980
Arbitrary Hyphens:	last-minutes [0190]
		        down-payments [0910]
		        long-term [0990]
2,034 words	127 (6.2%) quotes

A08. The Times-Picayune, [New Orleans], January 1, 1961, sec. 2, p.3
        	Used by permission of The Times-Picayune
	A.		"Pfaff Named ... "	                0010-0150
	B.		"Washington Panorama" by Edgar A. Poe	0160-0620
	C.		"Eyes on Mississippi" by W. F. Minor	0630-1170
	D.		"Louisiana Capital" by Robert Wagner	1180-1860
Typographical Errors: 	statutes [for statues] [0470]
		                       builtin [0770]
2,003 words	1 (0%) quotes 1 symbol

A09. The Philadelphia Inquirer, May 10, 1961, p.49
        	Used by permission of The Philadelphia Inquirer
	A.		"El Repair Bill Rigged"		0010-0620
	B.		"Council Gets Protest"		0630-0980
	C.		"Jail-Barnard Petitions"	0990-1110
	D.		"Planning Board OK's..."	1120-1390
	    	Chicago Daily Tribune
		Used by permission of Chicago Daily Tribune
	E. February 10, 1961, sec.F, p.9
			"Bomb Blows Up Auto"		1400-1740
	F. October 25, 1961, sec.I, p.16	
			"Gen. Gursel To Lead"		1750-1940
Typographical Errors:	severly [1420]
		  accomodations [0760]
2,017 words	99 (4.9%) quotes 6 symbols

A10. The Oregonian, [Portland]
        	Used by permission of The Oregonian
	A. October 24, 1961, p.8	"DA Selects..."		0010-0080
	B.				"Political Aid"		0090-0380
	C.				"School Board Requested"0390-0710
	D.				"War Mothers Plan..."	0720-0820
	E.				"Board Views School"	0830-0930
	F. November 29, 1961, p. 12	"Labor Chief..."	0940-1030
	G.				"11 Enter race"		1040-1140
	H.				"Delegates Vow..."	1150-1740
	I. October 24, 1961, p.8	"Judge In Fraud Trial"	1750-1940
Typographical Errors:	ritiuality [0190]
			Diety [1330]
			conpired [1890]
2,008 words	383 (19.1%) quotes 3 symbols

A11. The Sun, [Baltimore], March 18, 1961
        	Used by permission of The Sun
	A. Pp. 15, 18		"Orioles Bow..." by Jim Elliot	0010-0740
	B.			"Hansen Arrives" by Lou Hatter	0750-1380
	C. P.15			"Garden Fresh Wins" 
                   		  by William Boniface		1390-1585
	D. P.18			"Kerr Breaks 600-Yard"		1590-1770
	E.			"49ers Quarterback"		1780-1830
	F. P.15			"Yanks Drop 5-2..."		1840-1870
Arbitrary Hyphen:	pinch-hitters [0440]
Arbitrary No Hyphen:	Scrapiron [1370]
Typographicals Errors:	draought [0060]
			Dimaggio [1120]
			rookie-of-the year [0820]
			Wellsley College [1760]
			6-foot 3 inch [0860]
			righthandler [0090]
2,015 words	77 (3.8%) quotes 8 symbols

A12. The Dallas Morning News, October 10, 1961, sec. 2
		Used by permission of The Dallas Morning News
	A. P.1		"Steers Don't Kick" by Jimmy Banks	0010-0640
	B. P.2		"That Happy Feeling" by Roy Edwards	0650-1250
	C. P.3		"Texans Face Two..." by Charles Burton	1260-1650
	D. P.3		"Steers Set Record"			1660-1780
	E.		"MIT Tests Ball"			1790-1820
2,017 words	616 (30.5%) quotes 14 symbols

A13. Rocky Mountains News, [Denver, Colorado], May 2, 1961
		Used by permission of Rocky Mountains News
	A. P.50		"Nischwitz Posts 3rd Win" 
			   by Chet Nelson			0010-0420
	B.		"Kenny Lane in Easy Win"		0430-0470
	C.		"Billy Gardner's Double"		0480-0710
	D. P.51		"Sports" by Chet Nelson			0720-1000
	E.		"Jackie Jensen Tells..."		1010-1640
		The Dallas Morning News, October 10, 1961, sec. 2, p.1
		Used by permission of The Dallas Morning News
	F.		"Yanks Bury Reds..."			1650-1880
Typographical Errors:	gruonded [0140]
		no final quotes [1120]
2,014 words	374 (18.6%) quotes 7 symbols

A14. The New York Times, January 24, 1961, p. 23
		Copyright 1961 by The New York Times Company. Reprinted by permission.
	A.		"Skorich Is Promoted" 
 			  by William G. Weart 			0010-0350
	B.		"Baseball Award Voted" by Louis Effrat	0360-0860
	C.		"Palmer and Snead..."              	0870-1000
	D.		"Golf's Golden Boy" by Louis Effrat	1010-1720
	E.		"Football Owners Will..."		1730-1870
Arbitrary Hyphens:	title-holder [0930]
			head-on [1560]
Typographical Error:	diamond- studded [1060]
Note:	World Series [0440] and world series [0480]
		United States Open [1020,1320] and
		Los Angeles open [1180] Texas open [1310]
2,038 words	110 (5.4%) quotes

A15. St. Louis Post-Dispatch, May 2, 1961, p.4C
		Used by permission of St. Louis Post-Dispatch
	A.		"Cards and Broglio" by Neal Russo	0010-0700
	B.		"Benington Says..." 
			  by John J. Archibald			0710-1190
	C.		"No-Hitter Gives..."			1200-1330
	D.		"Sports Comment" by Bob Broeg		1340-1830
Typographical Error:	doesn's [1190]
		Bucks [for Bucs] [0390]
2,029 words	324 (16.0%) quotes 2 symbols

A16. Chicago Daily Tribune	
		Used by permission of Chicago Daily Tribune
	A. February 10, 1961, sec. 3, p.9 "Mrs. Joan M. Armour" 
				by Eleanor Page			0010-0500
	B. October 26, 1961, sec. 4, p.9 "Mrs. Geraghty..." 
 				by Eleanor Page			0510-1040
	C.                   sec. 1, p. 22,"Tower Ticker" 
				by Herb Lyon			1050-1680
	D. October 25, 1961, sec. 1, p.16 "Tower Ticker" 
				by Herb Lyon			1690-1940
Typographical Error:	no final ] [1770]
Note:	baseballight [1650]
2,043 words	143 (7.0%) quotes 2 symbols

A17. Rocky Mountain News, [Denver, Colorado]
		Used by permission of Rocky Mountain News
	A. April 21, 1961, p.102      "Gala Opening Slated" 
				       by Dorothy Jane Burke 	0010-0590
	B. May 16, 1961, p. 31	      "Meet Skid Row's Mom Marr" 
					by Marjorie Barret 	0600-0890
	C.			      "All American Safari" 
					by Inez Robb 		0900-1320
	  The Dallas Morning News, September 10, 1961, sec. 6, p.4
	  Used by permission of the Dallas Morning News
	D.			      "Judith Gay..."		1330-1440
	E.			      "Mason-Baker Rites"	1450-1700
	F.			      "Larry W. Mills"		1710-1860
	G.			      "Mr. Loving..."		1870-1920
Arbitrary Hyphen:	over-night [1110]
Typographical Error:	or [for of] [1840]
Illegible:	Te ? er [0420] recorded as Teter
2,005 words	68 (3.4%) quotes 7 symbols

A18. The Philadelphia Inquirer, March 26, 1961, p.16
        	Used by permission of The Philadelphia Inquirer
	A.		"Thrift Shop Gala"			0010-0600
	B.		"Chuchwomen Plan"			0610-0780
	C.		"April 8 Date Set" by Katherine Dunlap	0790-0890
	D.		"100 Artists"				0900-1160
	E.		"Notes of Interest"			1170-1320
	F.		"Drexel Hill notes"			1330-1500
	The Times-Picayune, [New Orleans], January 31, 1961, sec.3, p.4
	Used by permission og the Times-Picayune
	G.		"Miss Vieth's Engage..."		1510-1960
Typographical Errors:	Periods missing after A and Mrs [0780]
			Brelin [1350]
			shown (for shone) [1820]
			Muncipal [1790]
2,012 words	153 (7.6%) quotes 3 symbols

A19. The Sun, [Baltimore]
		Used by permission of The Sun
	A. January 8, 1961, p.36 "B &amp; O To Cut Payrolls"	0010-0210
	B.				"Bandit Strikes..."	0220-0330
	C.				"Baby Dies in Fire"	0340-0460
	D.				"Arundel School Chief" 
					 by Stuart S. Smith 	0470-0730
	E.				"Sen. Bertorelli..."	0740-0820
	F.				"Deficiencies Seen" 
					 by James S. Keat	0830-1110
	G.				"Slain Pair's Son"	1120-1380
	H.				"Simpkins Chosen" 
					 by Charles Whiteford	1390-1540
	I. December 10, 1961, sec. C, p.1"Building Awards"	1550-1680
	J.				"Apartment Demand..." 
					 by Carroll E. Wiliams 	1690-1860
	K.				"Apartment Addition"	1870-1950
	L.				"62 Construction"	1960-1980
2,004 words	98 (4.9%) quotes

A20. Chicago Daily Tribune, February 10, 1961
		Used by permission of Chicago Daily Tribune
	A. Pp. 1,2		"Charge Spies Got Secrets"
				 by Arthur Veysey		0010-1100
	B. P.9			"Dope Fighting Rivalry		1110-1470
	C. P.2			"Youths Slug And Rob"		1480-1610
	D.			"Parole Asked"			1620-1710
	E. P.9			"Fine Motorist $100"		1720-1870
Typographical Error:	advance [for advanced] [0970]
2,018 words	189 (9.4%) quotes 3 symbols

A21. The Detroit News
		Used by permission of The Detroit News
	A. April 19, 1961, p 3-A	"Pohl Convicted" 
					 by Allan Blanchard	0010-0430
	B.				"Hundreds help Family" 
					by Douglas Glazier 	0440-1100
	C.				"Wild Driver Tripped"	1110-1320
	D.				"Showdown Is Near"	1330-1600
	E.				"2 Yanks Executed"	1610-1840
	F. July 23, 1961, p. 15-A	"Slave laborer tells" 
					 by William W. Lutz	1850-1910
Typographical Errors:	somebody's else's [0140]
			pseudynom [1870]
			Furhmann's [for Fuhrmanns's] [0990]
			no final quotes [1020]
2,002 words	174 (8.7%) quotes 2 symbols

A22. The Atlanta Constitution
		Used by permission of The Atlanta Constitution
	A. November 4, 1961, pp. 1,5	"Emory to Integrate" 
					 by Bruce Galphin	0010-0570
	B. P.1				"Atlantan Killed"	0580-0670
	C.				"Will Integrate Theater"0680-1020
	D. April 17, 1961, p.18		Obituaries		1030-1240
	E.				"Atlantan, 24, Strikes"	1250-1480
	F.				"City Personnel Clerk"	1490-1600
	G.				"Program to Erase"	1610-1770
	H.				"14th Street Confusion"
				by Sgt. L. A. Pendergrass	1780-1880
	I. March 6, 1961, p.1		"Weekend traffic"	1890-2010
Repeated words:	applications from prospective students, and others [0440]
Typographical Errors:	church [for Church] [1070]
		Kililngsworth [1050, 1090]
2,023 words	440 (21.7%) quotes 18 symbols

A23. The Oregonian, [Portland], August 26, 1961, p.7
		Used by permission of the Oregonian
	A.				"Funds Face 2nd..."	0010-0620
	B.				"Police Nab Portlander"	0630-0800
	C.				"Bike Collision Hurts"	0810-0840
	D.				Obituary		0850-0940
	E.				"Clerks'Union Loses"	0950-1000
	F.				"Popular NW Musician"	1010-1230
	G.				"City Youth's Firm Wins"1240-1610
	H.				"Fair Nears Big Windup"	1620-1980
Arbitrary No Hyphen:	teenagers [1390]
		agencies [for agency's] [0200]
2,013 words	154 (7.7%) quotes 18 symbols

A24. The Providence Journal, November 29, 1961
		Used by permission of The Providence Journal
	A. P.22				"70 Taxpayers File"	0010-0130
	B.				"Hurt in 2-Car Crash"	0140-0230
	C.				"Home Ransacked"	0240-0390
	D.				"City Can't Fix..."	0400-0460
	E.				"Brown Buys House"	0470-0520
	F.				"Employes Picket"	0530-0610
	G.				"Crash Injures..."	0620-0780
	H.				"Warwick School Issue"	0790-0930
	I.				"Given $55,000"		0940-1050
	J.				"Santa Claus Fund"	1060-1170
	K.				"Youth Injures Heel"	1180-1260
	L. P. 23			"$4,177,37 Is Paid"	1270-1330
	M.				"Italy Wil Give..."	1340-1430
	N.				"Back from Patrol"	1440-1510
	O.				"FBI Arrests Jurar"	1520-1860
	P.				"New President..."	1870-1980
Typographical Error:	accessors [for assessors] [0020]
2,039 words	2 (0.1%) quotes 7 symbols

A25. San Francisco Chronicle, March 27, 1961, p.32
		Used by permission of San Francisco Chronicle
	A.			"Warning by Audubon Chief"	0010-0250
	B.			"Audubons Get Marin..."		0260-0350
	C.			"German Now at Sunnyvale"	0360-0820
	D.			"Officers for Columbus"		0830-0930
	E.			"Schweitzer Endorses..."	0940-1100
		Chicago Daily Tribune, October 26, 1961, sec. 3, p.2
		Used by permission of Chicago Daily Tribune
	F.			"Federal Jury Calls 10"		1110-1580
	G.			"Chicago's Air Radiation"	1590-1680
	H.			"Lawyer Tells of Thefts"	1690-1940
	I.			"OK Pact to Indemnify"		1950-1970
Arbitrary Hyphen:	micro-microcurie [1600]
2,006 words	319 (15.9%) quotes 4 symbols

A26. The Dallas Morning News, April 9, 1961, sec. 4, p.1
		Used by permission of The Dallas Morning News
	A.				"Morton Foods; Chip Stock"
					by Al Altwegg		0010-0750
	B.				"Dallas Is World Center" 
					by Tom Milligan 	0750-1340
	C.				"Dallas Auto Sales Gain" 
					by Rudy Rochelle 	1350-1540
	D.				"Sales Execs To Honor"	1550-1810
	E.				"FHA's Role Questioned"	1820-1880
2,031 words	30 (1.5%) quotes 1 symbol

A27. Los Angeles Times, June 21, 1961, sec. 4, p.6
		Used by permission of <i>Los Angeles Times</i>
	A.				"Historic Economic Peak" 
					 by Harold Walsh	0010-0490
	B.				"Stock Market Rebound"	0500-0680
	C.				"$800 Billion Seen"	0690-0950
	D.				"Taylor Voted Exchange"	0960-1000
	E.				"Union Oil Co. Makes.."	1010-1130
	F.				"Am Stock Exchange"	1140-1180
	G.				"Data Brain Slashes..." 
					 by William A.Doyle 	1190-1420
	H.				"International Reform"	1430-1500
	I.				"N.Y. Central Chief"	1510-1730
	J.				"U.S. Bill Costs Up"	1740-1770
		The Philadelphia Inquirer, March 12, 1961, sec. 2, p.1
		Used by permission of The Philadelphia Inquirer
	K.				"Builders Expect Sales" 
					 by Edward Cowan	1780-1950
Note:	superfluous comma in suggest, how [0460]
Arbitrary Hyphens:	know-how [0920]
			far-reaching [1450]
Typographical Errors:	arouny [for around] [0100]
			1,257,0000 [1890]
		Its [for It's] [0480]
		or [for of] [1410]
2,004 words	420 (21%) quotes 21 symbols

A28. The Wall Street Journal
		Used by permission of The Wall Street Journal
	A. October 4, 1961, p.1		"Rural Recovery" 
					 by Richard D. James	0010-0870
	B.				"Tax Report"		0880-1730
	C. May 11, 1961, p.2		"April Retail Sales"	1740-1870
2,013 words	153 (7.6%) quotes Typo: affects [for effects] [0520]

A29. The Dallas Morning News, September 10, 1961, sec. 6
		Used by permission of The Dallas Morning News
	A. P.6				"Greer Garson..."	0010-0740
	B. P.4				"SMU Wrangler" 
					 by Francis Raffeto	0750-1160
	C. P.1				"Warm, Sophisticated.."	1170-1650
	D. P.2				"Vagabonds'Are on..." 
					 by Ruby C. McKee	1660-1960
Arbitrary No Hyphen:	hotdogs [0990]
		Forsythe [for Forsyte] [570]
Typographical Errors:	simple [for simply] [0220]
		Tussard's [for Tussaud's] [0640]
2,017 words	151 (7.5%) quotes 9 symbols

A30. Los Angeles Times
		Used by permission of Los Angeles Times
	A. October 4, 1961, sec. II, p.1 "Housewife's Cooky" 
					  by Marian Manners	0010-0160
	B.				"Music Center Is..." 
					  By Ann Sonne		0170-0410
	C.				"String Artist Is..." 
					  by Dorothy Townsen 	0420-0540
	D.				"The Paths of Learning" 
					  by Jack Smith		0550-1000
	E. December 3, 1961, Soc.Sec., p.2 "Accent on Postive" 
					  by Mary Lou Loper	1010-1490
		The Sun, [Baltimore], December 10, 1961, sec. E, p.8
		Used by permission of The Sun
	F.				"Puppet Lamp Bases" 
					  by Pauline Graves	1500-1710
	G.				"It's Older..."		1720-1880
Arbitrary Hyphen:	home-owners [1730]
Note:		Pillsbury Bake-Off [0020] 
		10 past bake-offs [0050]
		the bake-off finals [0110]
2,016 words	65 (3.2%) quotes 2 symbols

A31. The Miami Herald
		Used by permission of The Miami Herald
	A. October 1, 1961, p. 12BE	"On the Nightbeat" 
					 by Patricia Brown	0010-0820
	B.				"Ballet Group to Kick"	0830-0930
	C.				"Hollywood to Be Host"	0940-1070
	D.				"JA Plans"		1080-1140
	E. May 6, 1961, p.11A		"Crusade Proving"	1150-1520
	F.				"Family Week Rites"	1530-1980
	G.				"Headmaster To Resign"	1990-2010
Typographical Errors:	Extra line of type [0560: man Restaurant on Sun-]
		Marskmen [0280]
		Mouse trap [0730f]
		Communisn [1360]
2,032 words	113 (5.6%) quotes 2 symbols

A32. San Francisco Chronicle
		Used by permission of San Francisco Chronicle
	A. November 12, 1961, p. 27	"Guest Appearances..."	0010-0180
	B.				"Wild Awake Beauties..." 
					by Alfred Frankenstein 	0190-0710
	C.			"Chamber Music Mail Orders"	0720-0830
	D.			"Firemen's Annual Toy Drive"	0840-0990
	E.			"White House Warmup"		1000-1060
	F. July 28, 1961, sec. 3, p.27	"How Dolce Was My Vita?"
					by Terence O'Flaherty	1070-1590
	G.				"San Francisco Postcard" 
					by Stanton Delaplane	1610-1890
Typographical Errors: 	an ytime[0250]
			thestage [0450]
			Bordeau [0090]
2,014 words	162 (8.0%) quotes 6 symbols

A33. The Washington Post
		Used by permission of The Washington Post
	A. August 23, 1961, sec. C, p.1	"Snubbed in His Lifetime" 
					 by Maxine Cheshire	0010-0360
	B.				"JFK Follows An Open Door" 
					 by Marie Smith 	0370-0940
	C.			"How They Got The Booking"	0950-1030
	D.				"Art Hath Charms"	1040-1350
	E. October 16, 1961, sec. B, p.1"Scottish Rite Group"	1360-1550
	F.				"Family Service Helps"	1560-1910
	G.				"Showers Put Damper"	1920-1950
Arbitrary Hyphens:	full-time [1240]
Typographical Errors:	completeset [0050]
			collonaded [1360]
			mantlepiece [0230]
			preceeded [1830]
			af [for of]
2,043 words	274 (13.4%) quotes 6 symbols

A34. The New York Times, May 21, 1961, sec. 4, p.1
	Copyright 1961 by The New York Times Company. Reprinted by permission
	"The News of the Week in Review"
2,035 words	142 (7.0%) quotes 1 symbol

A35. James J. Maguire, "A Family Affair"
   	Commonweal (November 10, 1961) 171-173	0010-1890
   	Used by permission of Commonweal
Note:	esprit de corps [0360,0660] esprit d'corps [0400]
2,006 words	138 (6.9%) quotes

A36. William Gomberg, "Unions and the Anti-Trust Laws"
	The Nation, 193: 16 (November 11, 1961), 375-377.	0010-1880
	Used by permission of The Nation
Arbitrary Hyphen:	multi-product [0480]
2,017 words	370 (18.3%) quotes 1 symbol

A37. "National Affairs"
	Time magazine, 77: 3 (January 13, 1961), 13-16.	0010-1930
	Used by permission of Time, Inc.
Arbitrary Hyphen:	far-out [0990]
2,022 words	183 (9.1%) quotes 1 symbol

A38. Alfred Wright, "A Duel Golfers Will Never Forget"
	Sports Illustrated (April 17, 1961), 18-21, 64.	0010-1670
	Copyright 1961 Time, Inc. By special permission
Arbitrary Hyphen:	flag-stick [0890]
2,005 words	35 (1.7%) quotes 1 symbol

A39. "Sports"
	Newsweek, 58: 7 (August 14, 1961), 42-45	0010-1790
	Used by permission of Newsweek
Arbitrary Hyphen:	knock-down [0220]
Note: no closing ) [1740]
Arbitrary No Hyphens:	halfback [0840]
2,004 words	355 (17.7%) quotes 1 symbol

A40. Time, 77: 3 (January 13, 1961)
	Used by permission of Time, Inc.
	A. P.32				"People"	0010-0790
	B. P.63				"Art"		0800-1210
	C. P.64				"Education"	1220-1890
Arbitrary Hyphens:	self-exile [0730]
			speech-making [1860]
2,029 words	284 (14.0%) quotes 1 symbol

A41. Robert Wallace, "This Is the Way It Came About"
	Life, 51: 24 (December 15, 1961), 32-34	0010-1890
	Used by permission of Time, Inc.
2,004 words	172 (8.6%) quotes

A42. "National Affairs"
	Newsweek, 58: 7 (August 14, 1961), 12-15	0010-1900
	Used by permission of Newsweek
2,013 words	154 (7.7%) quotes 5 symbols

A43. U.S. News and World Report, May 22, 1961
	Copyright 1961 U.S. News &amp; World Report, Inc., Washington
	A. Pp. 109-112		"Better Times ..."	0010-0940
	B. Pp. 113-114		"A Plan To Free..."	0950-1950
Typographical Errors:	attactive [1870]
2,011 words	223 (11.1%) quotes

A44. Saturday Review, 44: 15 (April 15, 1961)
	Used by permission of Saturday Review and John Tebbel (A)
	A. Pp. 24, 25, 75	"Books Go Co-operative"	0010-1500
				  by John Tebbel
	B. P.26			"Reading and the Free..."
				 by Gilbert W. Chapman	1510-1840
Arbitrary No Hyphen:	interlibrary [1330]
2,011 words	40 (2.0%) quotes
<hr><hr>

B. PRESS: EDITORIAL


B01. The Atlanta Constitution, March 6, 1961, p.4
	Used by permission of The Atlanta Constitution
	A.				Editorials	0010-1030
	B.				"Close-Up"	1040-1270
		The Washington Post, June 1, 1961, p.A24
		Used by permission of The Washington Post
	C.				Editorials	1280-1930
Typographical Error:	often-blood thirsty [1290]
2,012 words	43 (2.1%) quotes 4 symbols

B02. The Christian Science Monitor
		Used by permission of The Christian Science Monitor
	A. September 5, 1961, p.16	Editorials	0010-1190
	B. March 24, 1961, p.24		Editorials	1200-1890
2,030 words	77 (3.8%) quotes 12 symbols

B03. The Detroit News, November 17, 1961, p.8B
		Used by permission of The Detroit News
	A.				Editorials	0010-1140
	Chicago Daily Tribune, August 11, 1961, part I, p. 10F
	Used by permission of Chicago Daily Tribune
	B.				Editorials	1150-1770
Typographical Error:	period missing [0240]
2,007 words	26 (1.3%) quotes 8 symbols

B04. The Miami Herald, September 19, 1961, p. 6A
		Used by permission of The Miami Herald 
	A.				Editorials	0010-1560
		Los Angeles Times, August 4, 1961, part 3, p.4
		Used by permission of Los Angeles Times
	B.				Editorials	1570-1850
Arbitrary Hyphen:	anti-secrecy [1590]
2,006 words	325 (16.2%) quotes

B05. Newark Evening News
		Used by permission of Newark Evening News
	A. November 21, 1961, p.12	Editorials	0010-1230
	B. March 14, 1961, p.24		Editorials	1240-1890
Arbitrary Hyphen:	over-produce [0580]
2,027 words	70 (3.5%) quotes 4 symbols

B06. St. Louis Post-Dispatch, October 27, 1961, p.20
		Used by permission of St. Louis Post-Dispatch
	A.				Editorials	0010-1850
	B.				"The Governor Is Right"
			from The Columbia Daily Tribune	1860-1920
2,044 words	7 (0.3%) quotes 1 symbol

B07. The New York Times, October 17, 1961, p.38
		Copyright 1961 by The New York Times Company. Reprinted by permission.
	A.				Editorials	0010-1680
	B.				"Topics"	1690-1860
Arbitrary No Hyphen:	pocketbook [0800]
			nationwide [1360]
			groundwork [1280]
2,025 words 	53 (2.6%) quotes

B08. The Atlanta Constitution
		Used by permission of The Atlanta Constitution
	A. August 17, 1961, p.5		"DeKalb Cannery..." 
					 by Eddie Barker	0010-0450
	B.				"We must Forgive Others" 
					by Robert V. Ozment	 0460-0860
	C.				"There's Only One Test"
					by Calestine Sibley	0870-1250
	D. March 6, 1961, p.4		"A Pulpit Must Be..."
					by Eugene Patterson	1260-1690
Typographical Error:	metropolitian [0140]
2,031 words	585 (28.8%) quotes

B09. The Christian Science Monitor
		Used by permission of The Christian Science Monitor
	A. September 5, 1961, p.16	"But Do You Know It?"
					by Silence Buck Bellows	0010-0810
	B.				"Peaceable Desegre ..."
					by Bicknell Eubanks	0820-1460
	C. March 24, 1961, p.24		"I Like California..."
					by Joseph N. Bell	1470-1800
Arbitrary Hyphen:	straw-hat [0280]
Typo:	acquiesence [1650]
2,029 words	153 (7.5%) quotes 4 symbols

B10. The Sun, [Baltimore]
		Used by permission of The Sun
	A. March 18, 1961, Sports, pp. 1,18	"The Morning After"
						by Bob Maisel	0010-0790
	B. December 10, 1961, sec. E, p.8	"Handling Autistic..."
				by F.L. lig &amp; L.B.Ames	0800-1470
	C.		"Old Art of Embroid" by Betty Pepis	1480-1770
Typographical Errors:	Richard's [for Richards'] [0120]
		jim [0300]
2,003 words	344 (17.2%) quotes

B11. Los Angeles Times
		Used by permission of Los Angeles Times
	A. August 4, 1961, pt. 3, p.4	"State Democrats Ready"
					 by James Bassett	0010-0730
	B.				"A Short Lesson..."	
					 by Robert T. Hartmann	0740-1670
	C.				"Today in History" 
					 by Brainard Dyer	1680-1870
	D. December 3, 1961, Society, p.2 "Ziegfeld Girl Memories"
					by Wanda Henderson	1880-2060
Arbitrary Hyphens:	top-drawer [0130]
			rock-ribbed [0390]
			hard-nosed [0210]
2,025 words	620 (30.6%) quotes 21 symbols

B12. Newark Evening News
		Used by permission of Newark Evening News
	A. November 21, 1961, p.12	"Once Over"		0010-0490
	B.				"Washington Footnotes"
					 by William May		0500-0920
	C. March 14, 1961, p.24		"New Bible in Modern..."
					 by Margaret A. Vance	0930-1860
Typographical Error:	their's [1530]
2,012 words	298 (14.8%) quotes 5 symbols

B13. The Times-Picayune, [New Orleans]
		Used by permission of The Times-Picayune
	A. June 19, 1961, sec. 3, p.11	"Shoes Made For..." 
					 by Ann Audubon		0010-0310
	B.				"How To Keep Well"
					by Dr. T.R. Van Dellen	0320-0800
	C.				"On the Square" 
					 by Frank Gagnard	0810-1290
	D. January 31, 1961, sec.3, p.4	"Depressing Experiences"
					 by Clayton Rand	1300-1500
	E.				"Your Baby and Mine"
					 by Myrtle Meyer Eldred	1510-1830
Arbitrary Hyphen:	semi-heights [0100]
Typographical Errors:	Ille [for Ile] [240]
		bushing [for brushing] [0490]
		bushes [for brushes] [0400]
		of [for off] [0580]
		unforseen [1300]
		lacey [for lacy] [0170,0280]
		Peal [for Peale] [1220]
2,002 words	56 (2.8%) quotes 2 symbols

B14. The Atlanta Constitution
		Used by permission of The Atlanta Constitution, 
		Reg Murphy and Fletcher Knebel
	A. November 4, 1961, p.1	"Homecoming Games..."
					 by Ralph McGill	0010-0580
	B. March 6, 1961, p.1		"Republicans and..." 
					 by Ralph McGill	0590-1200
	C. April 17,1961, p.5		"Legislators Face..." 
					 by Reg Murphy		1210-1680
	D.				"Potomac Fever" 
					 by Fletcher Knebel	1690-1800
Typographical Errors:	lines misplaced [1490-1500] corrected in copy
			isa [1620]
			compelte [1670]
2,010 words	135 (6.7%) quotes 6 symbols

B15. The Providence Journal
		Used by permission of The Providence Journal
	A. February 3, 1961 p.21	"The East Greenwich"	0010-0910
	B.				"Thanks from..."	0920-1070
	C.				"She Wants To Study"	1080-1250
	D.				"Praise for the Rescue"	1260-1350
	E. February 5, 1961, p.N21	"A defense of the VA.."	1360-1750
	F.				"A Veteran Criticizes"	1760-1900
Typographical Error:	Governors [for Governor's or Governors'] [0310]
Note:	non-service-connected [1420, 1950]
	nonservice-connected [1550]
2,093 words	134 (6.4%) quotes 9 symbols

B16. Chicago Daily Tribune
		Used by permission of Chicago Daily Tribune
	A. August 12, 1961, p.1		"Voice of the People"	0010-1210
	B. August 11, 1961, p.2		"Voice of the People"	1220-1860
Typographical Error:	avaliable [1500]
2,010 words	44 (2.2%) quotes 6 symbols

B17. Newark Evening News
		Used by permission of Newark Evening News
	A. November 21, 1961, p.12 "What News Readers Have..."	0010-0720
	B. March 14, 1961, p.24	   "What Readers have to Say"	0730-0990
		The Washington Post
		Used by permission of The Washington Post
	C. June 1, 1961, p.24	   "Letters to the Editor"	1000-1780
Arbitrary Hyphen:	post-attack [1320]
Arbitrary No Hyphen:	manmade [1400]
Typographical Error:	case [for cause] [0760]
2,022 words	186 (9.2%) quotes 1 symbol

B18. The New York Times, October 17, 1961, p.38
		Copyright 1961 by The New York Times Company. Reprinted 
		by permission
	A.				"Letters to the Times"	0010-1270
		The Detroit News, November 17, 1961, p.8B
		Used by permission of The Detroit News
	B.				"The Public Letter Box"	1280-1830
Arbitrary Hyphen:	fall-outs [0080]
1,993 words	170 (8.5%) quotes 4 symbols

B19. The Philadelphia Inquirer, November 5, 1961, p. B 8
		Used by permission of The Philadelphia Inquirer
	A.			"The Voice of the People"	0010-1630
		The Detroit News, November 17, 1961, p. 8B
		Used by permission of The Detroit News
	B.			"The Public Letter Box"		1640-1820
Typographical Errors:	demage [0340]
		iniure [for inure] [1410]
2,013 words	53 (2.6%) quotes

B20. "Editorials"
	The Nation, 193: 16 (November 11, 1961), 365-367	0010-1820
	Used by permission of The Nation
2,013 words	194 (9.6%) quotes 1 symbol

B21. The New Republic, 145: 19 (November 6, 1961)
		Used by permission of The New Republic
	A. P.16				"The Cult of the Motor"
					 by Gerald W. Johnson	0010-0710
	B. Pp. 10-11			"How Much Fallout..."
					 by James Deakin	0720-1820
Typographical Error:	miniscule [0530]
2,029 words	150 (7.4%) quotes 12 symbols

B22. "Week by Week"
		Commonweal (November 10, 1961), 163-165	0010-1930
		Used by permission of Commonweal
Arbitrary Hyphen:	anti-recession [1390-1400]
Typographical Error:	Eisenhhower [1340]
Note:	Secretariat [0980] Secretariate [1060]
2,071 words	102  (4.9%) quotes

B23. National Review, xi: 26 (December 30, 1961)
		Used by permission of National Review, 150 E. 35th St.,NY 16
	A. Pp. 445, 462		"We Shall return"
				 by William F. Buckley, Jr.	0010-1030
	B. P. 446		"Tangle in Katanga" 
				 by James Burnham		1040-1810
Typographical Errors:	U.S. [1250] [U. S. elsewhere 1380,1410,1430]
		Gigenza [for Gizenga] [1440]
2,015 words	156 (7.7%) quotes 5 symbols

B24. "Reviews"
	Time magazine, 77: 3 (January 13, 1961), 54, 57, 60	0010-1900
	Used by permission of Time, Inc.
Arbitrary Hyphen:	shirt-sleeved [0670]
2,006 words	93 (4.6%) quotes

B25. The Nation, 193: 16 (November 11, 1961), 370-373
		Used by permission of The Nation
	A.			"Walkout in Moscow" 
				 by A. Werth			0010-1470
	B.			"The Armed Superpatriots" 
				 by Peter W. Salsich, Jr.	1480-1880
2,021 words	155 (7.7%) quotes 3 symbols

B26. National Review
	Used by permission of National Review, 150 E. 35th St., NY 16
	A. December 30, 1961, pp. 459-462	"To the Editor"	0010-1300
	B. July 15, 1961, pp. 27,29		"To the Editor"	1310-1850
Arbitrary Hyphen:	light-hearted [1760]
2,005 words	343 (17.1%) quotes 8 symbols

B27. Saturday Review
	Used by permission of Saturday Review
	A. April 15, 1961, p.27	"Letters to the Editor"		0010-0720
	B. April 8, 1961, p.52 "...to the Communications Editor"0730-1410
	C. April 1, 1961, p.44	"...to the Science Editor"	1420-1840
Arbitrary No Hyphen:	widespread [0050]
Typographical Error:	appear [for appeal] [0250]
2,022 words	146 (7.2%) quotes 10 symbols
<hr><hr>

C.  PRESS: REVIEWS


C01. Chicago Daily Tribune
		Used by permission of Chicago Daily Tribune
	A. February 10, 1961, pt.3,p.9		"On the Aisle"	0010-0380
	B. October 26, 1961, pt. 4, p.5		"On the Aisle"	0390-0730
	C.					"Art Notes"	0740-0820
	D.					"Opera Notes"	0830-0870
	The New York Times, January 21, 1961
	The New York Times Company, reprinted by permission.
	E. P. 19			"Books of the Times" 
					 by Charles Poore	0880-1450
	F. P. 18			"Screen: Don Quixote" 
					 by Bosley Crowther	1460-1960
Arbitrary No Hyphen:	Oneupmanship [1350]
Typographical Errors:	line of type missing [0230]
		transluscent [0250]
		Dutch [for Dutchman] [0320]
		no period after initial capital H [0880]
2,121 words	48 (2.3%) quotes

C02. The Christian Science Monitor, November 28, 1961
	Used by permission of The Christian Science Monitor
	A. P. 10c		"Television Tries...Jazz"
				 by Frederick H. Guldry		0010-0580
	B.			"Joan Sutherland's..."
				 by Miles Kastendick		0590-1050
	C.			"Anyone for Stereophonic..."	1060-1570
				 by Cedric Grainger		1060-1570
	D.			"Authenticity:..." 
				 by John C. Waugh		1580-1930
Typographical Errors:	soomed [0410]
		sort [for short] [1730]
2,045 words	131 (6.4%) quotes 11 symbols

C03. The New York Times
	Copyright 1961 by The New York Times Company. Reprinted by permission
	A. November 17, 1961, p.38  "D'Albert Plays Violin..."	0010-0280
	B. November 17, 1961, p.38	"Music: Anna Xydis, Pianist"
					 by Rose Parmenter	0290-0560
	C. P. 33			"Books of the times"
					 By Orville Prescott	0570-1290
	D. November 16, 1961, p.44	"Texas Boys Choir"	1300-1560
	E.				"Dance: An Engaging Polish"
					 by John Martin		1570-1930
Arbitrary No Hyphen:	airdrops [1080]
Typographical Errors:	Brahm's [for Brahms'or Brahms's] [0120]
		Geroge [for George] [1350]	
2,048 words	299 (14.6%) quotes 4 symbols

C04. The Providence Journal
	Used by permission of The Providence Journal
	A. July 4, 1961, p.26		"Theatre by the Sea"
					 by George H. Arris	0010-0290
	B.				"Newport Playhouse" 
					 by Ted Holmberg	0300-0650
	C.				"Warwick Musical Theater" 
					 by George Troy		0660-0980
	D. March 11, 1961, p.12		"Passed in Review" 
					 by Bradford F. Swan	0990-1520
	E. March 3, 1961, p.36		"Before the House" 
					 by Bradford F. Swan	1530-1890
Arbitrary Hyphen:	finger-tips [0390]
			ward-heelers [1330]
Arbitrary No Hyphens:	penthouse [1360]
Typographical Errors:	fiedgling [0130]
			youngsters [for youngster] [0240]
			as an appealing an Amy [0810]
			fugual [1300]
2,030 words	78 (3.8%) quotes 1 symbol

C05. The Christian Science Monitor, April 20, 1961
	Used by permission of The Christian Science Monitor
	A. P.C7				"That Adorable Genius" 
					 by Robert Peel		0010-0600
	B. P.C7				"Humor as a Thing..."
					 by Ben Crisler		0610-1190
	C.				"Not Quite the Same"
					 by Saville R. Davis	1200-1620
	D.				"Animals and Allegory..."
					 by Earl W. Foell	1630-1880
Arbitrary Hyphen:	motion-picture [0830]
2,066 words	442 (21.4%) quotes 2 symbols

C06. The Wall Street Journal, May 22, 1961, p.12
	Used by permission of The Wall Street Journal
	A.			"The Bookshelf" 
				 by William Henry Chamberlin	0010-1170
	B.			"The Theater"
				 by Richard P. Cooke		1180-1810
	The New York Times, July 7, 1961, p.16
	Copyright 1961 by The New York Times Company. Reprinted by permission.
	C.			"Screen: Fanny Captures..."
				 by Bosley Crowther		1820-1950
Typo:	Plebian [0800]
2,155 words	435 (20.2%) quotes

C07. The New York Times
	Copyright 1961 by The New York Times Company. Reprinted by permission
	A. January 21, 1961, p.17	"Music: Paray Conducts"
					 by Harold C. Schonberg	0010-0400
	B.				"Snow No Obstacle..."	0410-0670
	C. January 22, 1961, sec. 2, p.19	"Long-Lasting Tradition"
					 by Eric Salzman	0680-1440
	D. January 30, 1961, p.19	 "Rococo Concert" 
					  by Allen Hughes	1450-1600
	E. January 30, 1961, p.19	 "Joint Folksong Recital"
					  by A[llen] H[ughes]	1610-1750
	F. November 26, 1961, p.17	  "End of a Festival" 
					   by Eric Salzman	1760-2020
Arbitrary Hyphens:	non-romantic [0290]
			mid-century [1320]
			light-weight [1560]
Typographical Errors:	vocal chords [for cords] [0620]
			Thre [for There] [1710]
Note:	the performances...is characteristic [1340f]
2,077 words	37 (1.8%) quotes 12 symbols

C08. The Providence Journal
	Used by permission of The Providence Journal
	A. July 4, 1961, pp.1, 24	"Judy Garland Magic"
					 by Bradford F. Swan	0010-0640
	B. July 3, 1961, pp. 1,4	"Ligthning Flashes No Storm"
					 by Bradford F. Swan	0650-1620
	C. July 2, 1961, TV Weekly, p.19 "Gilels Plays Schubert" 
					  by Ruth Tripp		1630-1840
Arbitrary Hyphen:	wind-blown [0440]
Typographical Errors:	ballards [for ballads] teno [for tenor] [1590]
2,054 words	115 (5.6%) quotes 2 symbols

C09. The New York Times
	Copyright 1961 by The New York Times Company. Reprinted by permission
	A. November 27, 1961, p.36	"Dance: By Murray Louis"
					 by Allen Hughes	0010-0510
	B.				"Music: Van Cliburn Plays"
					 by Ross Parmenter	0520-0910
	C. November 26, 1961, sec. 2, p.20	"Never Let a Good Song"
					 by John S. Wilson	0920-1650
	D. January 30, 1961, p.17	"Screen: Russians in Love"
					 by Howard Thompson	1660-1900
Arbitrary Hyphens:	top-drawer [1270]
			block-buster [1690]
			high-up [1880]
Typographical Errors:	broodinf [0830]
			seemed to be fine shape [0510]
			accompanimen [period missing] [1310]
			lyriist [1460]
2,037 words	110 (5.4%) quotes 6 symbols

C10. The Providence Journal
	Used by permission of The Providence Journal
	A. March 11, 1961, p. W 20	"Magic in the West..."
					 by Harvena Richter	0010-0650
	B. March 5, 1961, p. W 18	"Comedie Francaise..."
					 by Henry Popkin	0660-1520
	C. July 2, 1961, TV Weekly, p.19 "The Art of Django..."
					 by Philips C. Gunion	1530-1910
Arbitrary Hyphen:	old-time [1900]
2,072 words	216 (10.4%) quotes 1 symbol

C11. The New York Times
	Copyright 1961 by The New York Times Company. Reprinted by permission.
	A. July 5, 1961, p.28		"Music: Elman at Stadium" 
					 by Eric Salzman 	0010-0260
	B. July 6, 1961, p.18		"Screen: Marital Problem" 
					 by Eugene Archer 	0270-0480
	C. July 5, 1961, p.31		"Ballet: Leningrad Gala" 
					 by John Martin		0490-1010
	D.				"Books of the Times" 
					 by Orville Prescott	1020-1810
	E. July 7, 1961, p.15		"Music: Lily Pons Heard" 
					 by Alan Rich		1820-2060
Typographical Error:	Kornevey [for Korneyev] [0960]
2,141 words	281 (13.1%) quotes 1 symbol

C12. The Christian Science Monitor, October 17, 1961, p.4
	Used by permission of The Christian Science Monitor
	A.				"Growing Service..." 
					 by Frederick H. Guidry	0010-0880
	B.				"Nostalgia for the Human"
					 by Dorothy Grafly	0890-1450
	C.				"Beethoven Heard..." 
					 by Louis Chapin	1460-1940
Typographical Errors:	Futhermore [0330]
			and and [0770]
			predominately [0490]
2,058 words	159 (7.7%) quotes 9 symbols

C13. The Wall Street Journal, March 8, 1961, p. 16
	Used by permission of The Wall Street Journal
	A. 			"The Bookshelf" 
				 by Edwin A. Roberts, Jr.	0010-0900
	B.			"The Theater" 
				 by Richard P. Cooke		0910-1350
	The New York Times, July 7, 1961, p.17
	Copyright 1961 by The New York Times Company. Reprinted by permission.
	C.			"Theatre: Poetic..." 
				 by Howard Taubman		1360-1860
2,033 words	33 (1.6%) quotes

C14. The New York Times
	Copyright 1961 by The New York Times Company. Reprinted by permission.
	A. November 27, 1961, p.36	"Recital is Given" 
					 by Eric Salzman	0010-0270
	B. July 3, 1961, p.9		"Dance:..." 
					 by Allen Hughes	0280-0620
	C. P.13				"Books of the Times"
					 by Orville Prescott	0630-1350
	D. P.31				"Radio: Return to Drama" 
					 by Jack Gould		1360-1670
	E. July 3, 1961, p.31		"Radio 4th Year of WQXR's..." 
					 by Lisa Hammel		1680-1890
	F. July 17, 1961, p.16		"Dance: Farewell Stand" 
					 by John Martin		1900-2120
2,246 words	272 (12.1%) quotes 4 symbols

C15. Life
	Used by permission of Life magazine. Copyright 1961 Time Inc.
	A. September 22, 1961 (51:12), p.21	"Life Guide"	0010-1530
	B. October 27, 1961 (51:17), p.27	"Life Guide"	1540-2030
2,171 words	11 (0.5%) quotes 3 symbols

C16. Saturday Review, 44:15 (April 15, 1961)
	Used by permission of Saturday Review, Ken W. Purdy and Eugene 
	Emerson Jennings.
	A. Pp. 19-20		"Destination: Death" 
				 by Ken W. Purdy		0010-0740
	B. Pp. 34-35		"A Time for Heroes"
				 by Eugene Emerson Jennings	0750-1740
	C. P. 47		"On First Hearing Lanza..." 
				 by I.K.			1750-1860
Arbitrary No Hyphen:	warton [0120]
2,021 words	185 (9.2%) quotes 4 symbols

C17. Time magazine, 77:3 (January 13, 1961), 48-50 "Reviews"	0010-1920
	Used by permission of Time Inc.
Arbitrary Hyphen:	horse-playing [0020]
2,019 words	205 (10.2%) quotes 1 symbol
<hr><hr>

D. RELIGION


D01. William G. Pollard, Physicist and Christian. 
	Greenwich, Connecticut: The Seabury Press, 1961, Pp. 54-59
	Copyright The Seabury Press, 1961. Used by permision	0010-1680
2,009 words	209 (10.4%) quotes

D02. Schubert Ogden, Christ Without Myth. New York: Harper and Brothers, 1961.
Pp. 128-134
	Copyright Schubert Ogden, 1961. 
	Used by permission of publisher, Harper and Row, Inc.
Typographical Error:	indigation [for indignation] [0630]
Note:	"understanded..." [0020]
2,054 words	82 (4.0%) in quotes 6 symbols

D03. Edward E. Kelly, S.J., "Christian Unity in England"
	America, 105: 10 (June 3, 1961), 398-400
	Reprinted with permission from AMERICA, the National Catholic
	Weekly Review, 920 Broadway, New York 10, N.Y.	0010-1940
	Typographical Error:	than [for that] [0770]
2,071 words	217 (10.5%) quotes

D04. Jaroslav Pelikan, The Shape of Death: life, death and immortality in the
early fathers.
	New York and Nashville, Tenneee:
	Abingdon Press, 1961. Pp. 102-109		0010-1700
	Copyright 1961 by Abingdon Press. Used by permission
2,011 words	498 (24.8%) quotes

D05. Perry Miller "Theodore Parker: Apostasy within Liberalism"
	The Harvard Theological Review, LIV: 4 (October, 1961), 280-285
	Copyright 1961 by the Faculty of Divinity in Harvard University. Used by
	permission	0010-1910
Typographical Error:	majesterial [1890]
2,119 words	364 (17.2%) quotes

D06. Tracts published by American Tract Society, 513 West 166th St.,
	New York 32, N.Y.1961. Not copyright.
	A. Howard A. Kelly, M.D., F.A.C.S.	"Out of Doubt..." 0010-0780
	B. Shirley E. Schuyler, R.N.		"Not As the World Giveth"	0785-1210
	C. Nathanael Olson		"Are You In Orbit?"	  1215-1700
Typographical Errors:	acording [0620]
Note:	Biblical quotations in all three
2,015 words	275 (13.6%) quotes

D07. Peter Eldersveld, "Faith Amid Fear"
	Radio message broadcast on "The Back-to-God Hour," 
	The Denominational Broadcast of The Christian Reformed Church.
	Chicago 1961
	Pp. 2-8. Used by permission			0010-1660
2,024 words	420 (20.8%) quotes

D08. Schuyler Cammann, "The Magic Square of Three in Old Chinese Phliosophy and
Religion,"
	History of Religions, 1:1 (Summer, 1961), 46-51
	Copyright The University of Chicago. Used by permission	0010-1840
2,022 words	24 (1.2%) quotes

D09. Eugene E. Golay, Organizing the Local Church for Effective Lay Visitation
Evangelism
	Nashville, Tennessee: Tidings, 1961, Pp. 54-61
	Copyright Tidings. Used by permission			0010-1950
2,056 words	67 (3.3%) quotes

D10. Huston Smith, "Interfaith Communication: The Contemporary Scene,"
	Journal of Bible and Religion, XXIX: 4 (October, 1961), 308-311
	Used by permission.			0010-1880
2,028 words	121 (6.0%) quotes

D11. Paul Ramsey, War and the Christian Conscience. Durham, North Carolina:
	Duke University Press for the Lily Endowment Research
	Program in Christianity and Politics, 1961. Pp. 200-206
	Copyright Duke University Press. Used by permission	0010-1770
2,042 words	574 (28.1%) quotes

D12. Kenneth Underwood and Elden Jacobsen, "Probing the Ethics of Realtors," 
	Christianity and Crisis, XXI: 9 (May 9, 1961), 96-98
	Used by permission.			0010-1970
Arbitrary Hyphen:	non-white [0620]
2,031 words	107 (5.3%) quotes 3 symbols

D13. Science of Mind, 34:11 (November, 1961)
	Copyright Church of Religious Science. Used by permission.
	A. Pp. 6-10, 49		"The New Science..."
			by Donald H. Andrews	0010-1490
	B. P. 43		"The Seeming Impossible"
			by George B. Longstreet	1500-1610
2,015 words	2 formulas 3 symbols

D14. Kenneth Scott Latourette, Christianity in a Revolutionary Age
	Volume 3: The Nineteenth Century Outside Europe. New York:
	Harper &amp; Brothers, 1961. Pp. 200-205
	Copyright Kenneth Scott Latourette. Used by permission of publisher,
	Harper &amp; Row, Inc.			0010-1900'
2,025 words	80 (4.0%) quotes

D15. Ernest Becker, Zen: A Rational Critique. New York: W.W. Norton 
	and Company, Inc.,1961 Pp. 104-111
	Copyright Ernest Becker. Used by his permission.	0010-1870
2,016 words	246 (12.2%) quotes

D16. Herald Press Tracts, Scottdale, Pa. No Copyright.
	A. "What the Holy Catholic Bible Teaches About the New Birth"	0010-1360
	B. "Notice: You May Do As You Please" by Harold Brenneman	1365-1650
Note:	Savior [0710]
		Saviour [1330,1360]
2,032 words	283 (13.9%) quotes 
		(Actually, A is almost all Biblical quotation)

D17. Guideposts
	Copyright by Guideposts Associates, Inc. Used by permission
	A. January, 1961, Pp. 1-5	"Guideposts: 15th 
					 Anniversary Issues	0010-1190
	B. February, 1961, Pp. 1-3	"The Night Our Paper Died"
					 by J.I.Rivero		1200-1780
Typographical Error:	brain-wracking [1060]
2,019 words	63 (3.1%) quotes 2 symbols
<hr><hr>

E. SKILL AND HOBBIES


E01. Mr. America, 4:6 (November, 1961)
	Used by permission.
	A. Pp.9-12,42-43		"Henri de Courcy [:] Junior Mr. Canada"
					 by Ben Weider		0010-1110
	B. Pp. 22,25,52			"The Mark of the Champ" 
					 by Joe Weider		1120-1910
Arbitrary Hyphen:	prize-winning [0240]
Typographical Errors:	hyphens missing [Super Set and solid rock] [0660,1060]
Note:	wide-grip [0600]
	widegrip [0850]
	lats and pecs [for lateral and pectoral muscles] (treated as symbols)
2,026 words	69 (3.4%) quotes 8 symbols

E02. Organic Gardening and Farming, January, 1961
	Used by permission.
	A. Pp. 63-65		"Plant a Carpet of Bloom"
				 by Dorothy Schroeder		0010-1081
	B. Pp. 74-77		"Avacado Is Something Special"	1090-1680
Note: words soil dampened, and each of the pegged- substituted [0810]
2,016 words	11 (0.5%) quotes 4 symbols

E03. Lt. Col. D.F. Martin, "Will Aircraft or Missiles Win Wars?"
	Flying, 68:2 (February, 1961), 32-33,80-83
	Used by permission.			0010-1860
Arbitrary No Hyphen:	mutimegaton [0660]
2,013 words	19 (0.9%) quotes 18 symbols

E04. High Fidelity, 11:10 (October,1961)
	Used by permission.
	A. Pp. 75-76		"The Schnabevel/Pro Arte Trout"
				 by Harris Goldsmith		0010-0930
	B. Pp.76-77		"The True Sound of a Solid Second"
				 by Robert C. Marsh		0940-1760
	C. P. 77		Review of Adam: 
				 Gisella by R.D.D.		1770-1910
Arbitrary Hyphens:	quasi-performer [1500]
			razor-edged [1880]
2,033 words	17 (0.8%) quotes 6 symbols

E05. Dog World, 46:4 (April, 1961)
	Used by permission.
	A. Pp. 28-30 		"The Younger Generation: 
				The Junior Division"
				 by Paul Nigro			0010-1630
	B. P. 30		"Use of Common Sense Makes Dogs
				Acceptable at Motels" 
				 by Patricia Barney		1640-1760
	C. P. 30		"The Malady Lingers On!"	1770-1810
Arbitrary No Hyphen:	overage [1190]
Note:	for whom the trophy is named after [1430]
Typographical Errors:	period missing [1300]
		proprieter [1670]
		a trophies [1620]
2,019 words	423 (21.0%) quotes 5 symbols

E06. Joseph E. Choate, "The American Boating Scene"
	Rudder, 77:1 (January, 1961), 31-32,35,82,84
	Used by permission.
Typographical Error:	Corp [for Corps] [0240]
1,999 words	2 symbols

E07. Paul Larson and Gordon Odegard, "How to design your Interlocking Frame,"
	Model Railroader, 28:2 (February, 1961), 57-65
	Used by permission.			0010-1750
Arbitrary Hyphens:	snug-fitting [1370]
Note:	the connection...concist [0120-0130]
2,080 words	33 (1.6%) quotes 19 symbols 13 formulas

E08. Don Francisco, "Formulas and Math Every Hot Rodder Should Know"
	Hot Rod Magazine, 14:1 (January, 1961), 26-28
	Used by permission.			0010-1800
2,017 words	10 (0.5%) quotes 10 symbols 19 formulas

E09. The Horseman and Fair World, 84:46 (February 8, 1961)
	Used by permission.
	A. Pp. 11-13		"The Week at Ben White Raceway"
				 by Dr. Don McMahan		0010-1571
	B. P. 23		"The Picture at Del Mar" 
				 by Edith Shaw			1580-1880
Arbitrary Hyphen:	Work-outs [1640] [work-out in 0150 and 0640]
			[workout in 1590]
Note:	short dashes in sire-dam combinations treated as hyphens
Typographical Errors:	, [for .] [1290]
			it [for is] [1530]
1,948 words	5 (0.3%) quotes 63 symbols

E10. Larry Koller, "The New Guns of '61"
	Guns and Hunting, 4:4 (December, 1961), 9-11,71-74
	Used by permission.			0010-1860
Arbitrary Hyphen:	drop-block [1450]
2,126 words	12 symbols 2 formulas

E11. Idwal Jones, "Santa Cruz Run"
	Gourmet, xxi:1 (January, 1961), 12-13,22-24
	Used by permission			0010-1720
2,020 words	3 (0.1%) quotes

E12. Julia Newman, "Travel and Camera USA"
	U.S.Camera, 24:4 (April, 1961), 40-48
	Used by permission 			0010-1930
Note:	water-ski [0740]
   	waterskiing [1220]
2,013 words	7 (0.3%) quotes 1 symbol 2 formulas

E13. Robert Deardorff, "Step by Step Through Istanbul"
	Travel, 116:6 ( December, 1961), 51-53
	Used by permission 			0010-1720
2,011 words	1 symbol

E14. Ann Carnahan, Nick Manero's Cook-out Barbeque Book
	New York: Fawcett Publications, Inc., 1961. Pp. 13-21
	Copyright 1961 Fawcett Publications, Inc. Used by permission	0010-1810
2,026 words	14 (0.7%) quotes 2 symbols 1 formula

E15. McCall's Needlework and Crafts, Spring-Summer, 1961
	Used by permission 
	A. Pp. 70-71, 77	"Pottery from Old Molds"	0010-1510
	B. P. 16		"Knitting Knacks"		1520-1780
2,002 words	7 (0.3%) quotes 24 symbols 2 formulas

E16. Hal Kelly, "Build Hotei"
	Mechanix Illustrated, 57:7 (July, 1961), 102-108, 138-139
	Used by permission.			0010-1650
Arbitrary No Hyphens:	headroom [0040]
			runabout [0120]
			waterways [0290]
2,004 words	6 symbols 2 formulas

E17. The Family Handyman, 11:5 (October, 1961)
	Used by permission 
	A. Pp. 13-19, 58	"This Is the Vacation Cottage You 
				Can Build"			0010-0830
	B. Pp. 31-33		"Care and Basic Use of the Drill Press"
				by Patrick K. Snook		0840-1670
Typographical Error:	effect [for affect] [0600]
2,018 words	3 symbols 8 formulas

E18. Covered Bridge Topics, XIX:2 (July, 1961)
	Used by permission 
	A. Pp. 1,8		"The Bridge over the Merrimac"
				 by Lura Woodside Watkins	0010-1100
	B. P.7			"Veteran Philippi Bridge A Center of 
				Battle Centennial Observance"
				 by Boyd B. Stutler		1110-1800
Arbitrary Hyphen:	share-holders [0750]
Note:	so frequently has pictures appeared [1360]
Typographical Errors:	master piece [1460]
			strengtened [1480]
			momentoes [1540]
2,025 words	462 (22.8%) quotes


E19. Booth Hemingway and Stuart H. Brown,
	"How to Own a Pool and Like It"
	House and Garden, 119:6 (June, 1961), 136-145
	Used by permission 			0010-1690
Arbitrary Hyphen:	non-skid [1100]
Note:	pool-owners [0600]
2,016 words	16 (0.8%) quotes 1 symbol

E20. [Anonymous,] "What You Should Know About Air Conditioning for New
Homes,"
	How-to-Do-It-Encyclopedia. New York: Golden Press, 1961, Volume 1, pp.9-14
	Used by permission 			0010-1750
2,001 words 	13 symbols

E21. Richard I. McCosh, "Recreation Site Selection"
	Recreation, LIV:10 (December, 1961), 529-531
	Used by permission 			0010-1720
Typographical Error:	organ-tion [for organization] [0030]
2,002 words

E22. Musical America, LXXXI:5 (May, 1961)
	Used by permission 
	A. Pp. 13-14		"Roy Harris Salutes Serge Prokofieff"
				 by Roy Harris	0010-1900
	B. P. 19		"A 30 Years War: The Musician Emergency
				 Fund..."
				 by Helen Havener		1910-1960
2,030 words	90 (4.4%) quotes

E23. Norman Kent, "The Watercolor Art of Roy M. Mason"
	American Artist, 25:3 (March, 1961), 28-33, 64-65
	Used by permission 			0010-1760
2,001 words	861 (43.0%) quotes 1 formula

E24. Bonnie Prudden, "The Dancer and the Gymnast"
	Dance Magazine, XXXV:4 (April, 1961), 20, 52-54
	Used by permission
Typographical Error:	wive's [0570] 			0010-1720
2,007 words

E25. Walter H. Buchsbaum, "Advances in Medical Electronics"
	Eectronics World, 66:5 (November, 1961), 33-36
	Used by permission 			0010-1910
Arbitrary No Hyphen:	gastrointestinal [1480]
Typographical Error:	eventually [0040]
2,022 words	24 (1.2%) quotes 7 symbols 1 formula

E26. Bern Dibner, "Oerstad and the Discovery of Electromagnetism"
	Electrical Engineering, 80:6 (June, 1961), 426-428
	Used by permission 			0010-1850
Typographical Error:	Han's [for Hans'] [0470]
2,012 words	388 (19.3%) quotes

E27. Successful Farming, 59:12 (December, 1961)
	Used by permission 
	A. Pp. 51,68		"What Can 'Additives' Do for Ruminants?"	
				 by Mike Bay			0010-1680
	B. P. 52		"Which Feed Bunk for You"
				 by Dr. James S. Boyd		1690-1890
2,002 words	3 (0.1%) quotes 2 symbols

E28. John R. Sargent, "Where To Aim Your Planning for Bigger Profits in
'60s,"
	Food Engineering, 33:2 (February, 1961) 34-37
	Used by permission 			0010-1970
Arbitrary Hyphen:	top-notch [1760]
2,008 words	5 (0.2%) quotes 3 symbols

E29. Edward Austin Walton, "On Education for the Interior Designer"
	Interior Design, 32:7 (July, 1961), 61-62, 100
	Used by permission 			0010-1880
Typographical Errors:	corp [for corps or core] [1440]
			aquisiation [1690]
			badly [for baldly ?] [0090]
			ring-around-a rosy [1700]
2,018 words	163 (8.1%) quotes

E30. [Anonymous,] "The Attack on Employee Services"
	Factory, 119:11 (November, 1961), 98-101
	Used by permission 			0010-1930
Typographical Errors:	indiscriminantly [0970]
		deductable [1340]
2,008 words	3 (0.1%) quotes 2 symbols

E31. Sports Age, 24:9 (September, 1961)
	Used by permission 
	A. Pp. 15,16,66		"Expanding Horizons" by Jim Dee	0010-1080
	B. Pp. 56-58		"The Challenge" 
				 by George Laycock		1090-1910
Arbitrary Hyphen:	grass-roots [0920]
2,005 words	3 (0.1%) quotes 14 symbols

E32. E.J.Tangerman, "Which Way Up...Technical or Management?"
	Product Engineering, 32:33 (August 14, 1961), 31-34
	Used by permission 			0010-2030
Typographical Error:	egnieers [1770]
Note:	High proportion of material quoted is answers to questionnaire
2,052 words	1,164 (56.7%) quotes 16 symbols 1 formula

E33. Fueloil and Oil Heat, 20:7 (July, 1961)
	Used by permission 
	A. Pp. 49-50			"Fifty Houses, One Tank" 
					 by Robert Gray		0010-1250
	B. P. 98			"Truck Talk" 
					 by Chet Cunningham	1260-1770
Arbitrary No Hyphen:	Dowguard [1430]
Typographical Errors:	form [for from] [0650]
			it [for it's or it is] [1300]
2,011 words	12 (0.6%) quotes

E34. [Anonymous,] "The New Look in Signs,"
	Modern Plastics, 38:8 (April, 1961), 90-92, 164-166,171
	Used by permission 			0010-1920
2,010 words	2 symbols

E35. [Anonymous,] "The Industrial revolution in Housing"
	House and Home, XX:4 (October, 1961), 120-127
	Used by permission 			0010-1780
Typographical Error:	at little at [for as little as] [1110]
Note:	fork-lift [0920]
   	forklift [1020]
2,000 words	342 (17.1%) quotes 22 symbols 2 formulas

E36. Ethel Norling, "Renting a Car in Europe,"
	Playbill, 5:11 (March 13, 1961), 5-11
	Used by permission 			0010-1710
Note:	Nationalcar [0350]
2,012 words	6 (0.3%) quotes 1 symbol
<hr><hr>

F. POPULAR LORE


F01. Rosemary Balckmon, "How Much Do You Tell When You Talk?"
	Vogue, 138:1 (July, 1961), 40-41,100
	Used by permission 			0010-1900
Typographical Error:	X Rays [1820]
2,021 words	85 (4.2%) quotes 1 symbol 5 formulas

F02. Glenn Infield, "America's Secret Poison Gas Tragedy"
	True, 42:290 (July, 1961), 27-28,98-99
	Used by permission 			0010-1770
Typographical Error:	hole [for hold] [0470]
2,009 words	221 (11.0%) quotes 7 symbols

F03. Nathan Rapport, ""I've Been Here before!"
	Fate, 14:4 (April, 1961), 65-70
	Used by permission 			0010-1820
2,008 words 	223 (11.1%) quotes

F04. Ruth F. Rosevear, "North Country School Cares for the Whole Child,"
	Prevention, 13:9 (September, 1961), 82-83,85,88
	Used by permission 			0010-1790
Typographical Error:	deserts [for dessert] [1240]
Note:	home-made [1140] homemade [1650]
2,006 words	172 (8.6%) quotes 2 symbols

F05. Richard Sanders Allen, "When Fogg Flew the Mail"
	Vermont Life, XVI: 1 (Autumn, 1961), 18-22
	Used by permission 			0010-1800
Arbitrary Hyphen:	sheep-lined [1220]
2,013 words	65 (3.2%) quotes 2 symbols

F06. Modern Maturity, 4:6 (December, 1961-January, 1962)
	Used by permission
	A. Pp. 18-19		"Let's Discuss Retirement"	0010-1190
				 by Alice Heath Austin
	B. P. 31		"What it Means to be Creative"
				 by Harold P. Winchester	1200-1720
Typographical Errors:	burst [for bursts] [0310]
		specie [for species] [1360]
2,049 words	101 (4.9%) quotes 1 symbol

F07. Sexology, 28:1 (August, 1961)
	Used by permission 
	A. Pp. 35-38		"How to Have a Successful Honeymoon"	
	 			 by Marvin Sentnor, M.D. and 
				Stephen Hult, M.D.		0010-1520
	B. Pp. 39-40		"Attitudes Toward Nudity"
				 by Reverend H. Walter Yoder	1530-1810
2,014 words	80 (4.0%) quotes

F08. Philip Reaves, "Who Rules the Marriage Bed?"
	Pageant, 17:5 (November, 1961), 46-51
	Used by permission			0010-1860
Arbitrary No Hyphen:	checkbook [1330]
Typographical Error:	threshhold [0980]
2,018 words	300 (14.9%) quotes 1 symbol

F09. Confidential, 9:1 (January, 1961)
	Used by permission 
	A. Pp. 37-39 	"The Fantastic Life and Death of the Golden
			 Prostitute"  by David Martinson	0010-1690
	B. P. 40	"When It Comes to Carpets-Don't Be a Wall-
			 to-Wall Sucker" by Isel D. Rugget	1700-1790
Arbitrary Hyphen:	play-girl [0170]
2,010 words	481 (23.9%) quotes 1 symbol

F10. Jack Kaplan, "The Health Machine Menace: Therapy by Witchcraft"
	Today's Health, 39:2 (February, 1961), 28-31,81-82
	Used by permission of Today's Health, published by the 
	American Medical Association			0010-1850
2,006 words	211 (10.5%) quotes 10 symbols

F11. Lilian Pompian, "Tooth-Straightening Today"
	Everywoman's Family Circle, 58:3 (March, 1961), 8,107
	from Family Circle Magazine, March, 1961, by permission of the
	author and publisher. Copyright, 1961, by The Family Circle, Inc. 0010-1840
Arbitrary Hyphen:	whole-heartedly [0110]
Typographical Error:	peridontal [0820]
2,037 words	312 (15.3%) quotes 1 symbol

F12. Marian Nester, "New Methods of Parapsychology"
	Tomorrow, 9:4 (Autumn, 1961), 45-50		0010-1760
	Used by permission 
2,008 words	212 (10.6%) quotes 7 symbols

F13. Orlin J. Scoville, Part-Time Farming
	Farmers Buletin No. 2178. United States Department of Agriculture,
	December, 1961, Pp.2-3,5-7			0010-1780
Arbitrary Hyphen:	labor-saving [0140]
Typographical Error:	sometime [for sometimes] [0520]
2,076 words

F14. Harold Rosenberg, "The Trial and Eichmann"
	Commentary, 32:5 (November, 1961), 371-374	0010-1860
	Copyright 1961 by American Jewish Committee. Used by permission.
Arbitrary Hyphen:	light-mindeness [0820]
Typographical Errors:	" a [1100]
			had began [1180-1190]
2,030 words	60 (3.0%) quotes 2 symbols

F15. The Rev. John A. O'Brien, "Let's Take Birth Control Out of Politics,"
	Look Magazine, 25:21 (October 10, 1961), 67-70
	Copyright 1961 by Cowles Magazines and Broadcasting, Inc.
	Used by permission			0010-1920
2,007 words	236 (11.8%) quotes 1 symbol

F16. James Boylan, "Mutinity"
	Real, 14:2 (December, 1961), 17-18,59-60
	Used by permission 			0010-1770
Note:	Sevententh Century spellings within quotations
2,002 words	32 (1.6%) quotes

F17. John Harnsberger and Robert P. Wilkins,
	"Transportation on the Northern Plains,"
	The North Dakota Quarterly, 28:1 (Winter, 1961), 20-23
	Used by permission 			0010-1780
Typographical Errors:	Comany's [0060]
			prohibiton [1600]
			United State [0880]
Note:	Hudson Bay [0110]
	Hudson's Bay [1630]
	Hudson's Bay Company [1010, 1030]
2,023 words	67 (3.3%) quotes

F18. Bell I. Wiley, "Home Letters of Johnny Reb and Billy Yank,"
	The Centennial Review, V (1961), 56-61
	Used by permission of 			0010-1760
Arbitrary Hyphen:	cross-writing [0690]
Typographical Error:	extra " [0380]
Note:	illiterate spelling in quotations
2,042 words	1022 (50.0%) quotes

F19. Tristram P. Coffin, "Folklore in the American Twentieth Century,"
	American Quarterly, 13:4 (Winter, 1961), 526-530
	Used by permission 			0010-1890
Typographical Error:	progandist [1310]
		publically [1780]
2,069 words	20 (1.0%) quotes

F20. Kenneth Allsop, The Bootleggers and Their Era
	Garden City, New York: Doubleday &amp; Co., Inc., 1961. Pp.68-72
	Copyright 1961 by Kenneth Allsop. Reprinted by permission 
	of Doubleday &amp; Company, Inc.			0010-1840
Arbitrary Hyphens:	speak-easy [1640]
Typographical Error:	proprieter [0950]
2,008 words	158 (7.9%) quotes

F21. L. Don Leet and Florence J. Leet, editors, The World of Geology.
New York: McGraw-Hill Book Company, Inc., 1961.
	Used by permission 
	A. Pp. 140-145			"Giant Waves" 
					 by Joseph Bernstein	0010-1350
	B. Pp. 147-148			[Introduction to C]	1360-1700
	C. P. 149			"The Restless Earth and its Interior"
					 by L. Don Leet		1700-1730
Arbitrary Hyphen:	by-products [0780]
2,009 words	1 symbol

F22. Booton Herndon, "From Custer to Korea, The 7th Cavalry"
	Saga, 22:6 (September, 1961), 58-60
	Used by permission 			0010-1890
Arbitrary Hyphen:	machine-gun [1150]
2,164 words	15 (0.7%) quotes 12 symbols

F23. Barry Goldwater, "A Foreign Policy for America"
	National Review, X:11 (March 25, 1961), 177-179
	Used by permission 			0010-1840
Typographical Errors:	imperfectability [0140]
			troubie [1420]
			consisently [0420]
2,018 words	72 (3.6%) quotes

F24. Peter J. White, "Report on Laos"
	National Geographic, 120:2 (August, 1961), 241-247
	Copyright 1961 National Geographic Society. Used by permission	0010-1800
2,030 words	202 (10.0%) quotes 1 symbol

F25. David Boroff, "Jewish Teen-Age Culture"
	The Annals of the American Academy of Political and Social Science
	338 (November, 1961) 82-85
	Used by permission 			0010-1880
2,014 words	262 (13.0%) quotes

F26. Amy Lathrop, "Pioneer Remedies from Western Kansas"
	Western Folklore, 20:3 (July, 1961), 6-10
	Used by permission 			0010-1650
2,011 words	22 (1.1%) quotes

F27. Creighton Churchill, A Notebook for the Wines of France
	New York: Alfred A. Knopf, 1961. Pp. 124-129
	Used by permission 			0010-1680
2,017 words	38 (1.9%) quotes

F28. Frank Otto Gatell, "Doctor Palfrey Frees His Slaves"
	New England Quarterly, 34:1 (March, 1961), 78-84
	Used by permission 			0010-1800
2,021 words	288 (14.3%) quotes

F29. Douglass Cater, "The Kennedy Look in the Arts"
	Horizon: A Magazine of the Arts, IV:1 (September, 1961), 10-14
	Used by permission 			0010-1930
Arbitrary Hyphens:	anti-intellectual [0260]
			trouble-shooter [0790]
			long-time [0570]
2,016 words	158 (7.8%) quotes

F30. Fredric A. Birmingham, The Ivy league Today
	New York: Thomas Y. Crowell Co., 1961. Pp.142-149
	Used by permission 			0010-1820
Arbitrary Hyphens:	self-evident [0660]
			over-emphasized [1710]
2,001 words	96 (4.8%) quotes

F31. Edward D. Radin, Lizzie Borden: The Untold Story
	New York: Simon and Schuster, 1961. Pp. 208-214
	Used by permission 			0010-1710
2,012 words	92 (4.6%) quotes

F32. Florence Matilda Read, The Story of Spelman College
	Princeton: Princeton University Press, 1961. Pp. 166-171
	Used by permission 			0010-1800
2,005 words	356 (17.8%) quotes

F33. James Bryant Conant, Slums and Suburbs
	New York: McGraw-Hill Book Company, Inc., 1961. Pp.42-47
	Used by permission 			0010-1760
2,017 words	51 (2.5%) quotes

F34. Frederic R. Senti and W. Dayton Maclay, "Age-Old of Seeds 
	and some New Ones," 
	Seeds (The Yearbook of Agriculture)
	U.S. Department of Agriculture, Washington, D.C., 1961
	Pp. 28-31			0010-1820
Arbitrary Hyphen:	oil-bearing [1121]
Note:	Japanese and Indonesian words
2,001 words	1 (0.0%) quote

F35. Ramon F. Adams, The Old-Time Cowhand
	New York: The Macmillian Company, 1961. Pp. 160-165
	Used by permission 			0010-1790
Note:	Prose written in language of title,
		as explained in foreword
2,034 words	187 (9.2%) quotes

F36. Robert Easton and Mackenzie Brown, Lord of Beasts
	Tucson: University of Arizona Press, 1961. Pp. 188-194
	Used by permission 			0010.1700
2,029 words	166 (8.2%) quotes

F37. Samuel McCrea Cavert, On the Road to Christian Unity
	New York: Harper &amp; Brothers, 1961. Pp. 136-141
	Used by permission 			0010-1770
2,024 words	50 (2.5%) quotes

F38. Robert Smith, Baseball in America
	New York: Holt, Rhinehart and Winston, Inc., Pp.199-200,202-204
	Copyright 1961 by Robert Smith. 
	Reproduced by permission of Holt, Rinehart and Winston, Inc.
Arbitrary No Hyphen:	payday [0320]
		weekends [1510]
2,152 words	37 (1.7%) quotes 1 symbol

F39. Clark E. Vincent, Unmarried Mothers
	New York: The Free Press of Glencoe, Inc., 1961. Pp. 254-261
	Used by permission 			0010-2060
Arbitrary Hyphen:	long-term [0130]
Typographical Errors: 	Erickson [for Erikson] [0470]
                     	carreer [1130]
			again [for against] [1780]
			consderation [1500]
			Lohman [Loman] [1800]
2,077 words	50 (2.4%) quotes 1 symbol

F40. William Greenleaf, Monopoly on Wheels
	Detroit: Wayne State University Press, 1961. Pp. 240-245
	Used by permission			0010-1910
Typographical Error (within quotation):	beneficient [1410-1420]
2,005 words	457 (22.8%) quotes 1 symbol

F41. George W. Oakes, Turn Right at the Fountain
	New York: Holt, Rinehart and Winston, Inc., 1961. Pp. 152-159
	Copyright 1961 by George W. Oakes. Used by permission	0010-1790
Note:	Pages 154-155 missing; prose continuity unbroken
2,028 words	12 (0.6%) quotes

F42. James Baldwin, Nobody Knows My Name
	New York: Dial Press, 1961. Pp. 66-74
	Used by permission 			0010-1760
2,009 words	38 (1.9%) quotes

F43. Frank Getlein and Harold C. Gardiner, S.J., Movies, Morals, and Art.
	New York: Sheed and Ward, Inc., 1961. Pp. 48-54
	Copyright 1961 by Sheed and Ward, Inc. Used by permission 0010-1720
Typographical Error:	dazzling,magician's [0800]
2,017 words	8 (0.4%) quotes

F44. Gibson Winter, The Suburban Captivity of the Churches
	New York: Doubleday &amp; Company, Inc., 1961. Pp. 70-75
	Copyright 1961 by Gibson Winter. 
	Used by permission of Doubleday &amp; Company, Inc.	0010-1940
2,013 words	26 (1.3%) quotes

F45. Paul Chrisler Phillips, The Fur Trade
	Norman: The University of Oklahoma Press, 1961. Volume 1, pp. 466-472
	Copyright 1961 by The University of Oklahoma Press. Used by permission.
0010-1810
2,023 words	18 (0.9%) quotes

F46. Russell Baker, An American in Washington
	New York: Alfred A. Knopf, 1961. Pp. 118-127
	Used by permission			0010-1920
Typographical Error:	Uncle's Sam's [0260]
2,018 words	94 (4.7%) quotes 1 symbol

F47. Clara L. Simerville, Home Visits Abroad.
	Corvallis: Oregon State University Press, 1961. Pp. 62-66
	Used by permission 			0010-1720
Typographical Error:	diety [0300]
2,045 words	4 (0.2%) quotes 1 symbol

F48. Paul Ramsey, Christian Ethics and Sit-In
	New York: Association Press, 1961. Pp. 108-115
	Used by permission 			0010-1810
Arbitrary Hyphen:	pre-conditions [0560]
2,019 words	295 (14.6) quotes 1 symbol
<hr><hr>

G. BELLES-LETTRES


G01. Edward P. Lawton, "Northern Liberals and Southern Bourbons"
	The Georgia Review, 15 (1961), 254-259.
	Used by permission 			0010-1840
Typographical Error:	Northeners [1680]
2,061 words	19 (0.9%) quotes

G02. Arthur S. Miller, "Toward a Concept of National Responsibility"
	The Yale Review, LI:2 (December, 1961), 186-191
	Used by permission 			0010-1930
Typographical Error:	socal [1370]
2,031 words	73 (3.6%) quotes

G03. Peter Wyden, "The Chances of Accidental War"
	The Saturday Evening Post, June 3, 1961, 18-19, 60-61
	Copyright 1961 by The Curtis Publishing Company. Used by permission
Note:	preprepared [1110, 1630]	0010-1920
2,057 words	105 (5.1%) quotes 22 symbols

G04. Eugene Burdick, "The Invisible Aborigine"
	Harper's Magazine, 223:1336 (September, 1961), 70-72
	Copyright 1961 by Eugene Burdick. Used by permission	0010-1690
Note:	Australian words [0750, 0990, 1330, 1640]
2,074 words	299 (14.4%) quotes

G05. Terence O'Donnell, "Evenings at the Bridge"
	Horizon, III:5 (May, 1961), 26-30
	Copyright by American Horizon, Inc. Used by permission	0010-1730
Note:	obsolete spelling aromatick [0110]
		Persian words [0830, 1300, 1320]
2,069 words	95 (4.6%) quotes

G06. The American-German Review, October-November, 1961
	Used by permission 
	A. Pp. 26-28	Ruth Berges, "William Steinberg, Pittsburgh's 
			Dynamic Conductor"	0010-1540
	B. Pp. 28-29	Henry W. Koller, "German Youth Looks 
			at the Future"	1550-1910
Typographical Error:	no final'[1340]
2,080 words	356 (17.1%) quotes 3 symbols

G07. Richard B. Morris, "Seven Who Set Our Destiny"
	The New York Times Magazine, February 19, 1961, 9, 69-70
	Copyright 1961 by The New York Times Company. Reprinted by 
	permission 0010-1930
Arbitrary Hyphens:	single-handledly [0800]
			power-starved [0980]
			super-imposed [1650]
2,010 words	289 (14.4%) quotes

G08. Frank Murphy, "New Southern Fiction: Urban or Agrarian?"
	The Carolina Quarterly, 13:2 (Spring, 1961), 18-25
	Used by permission 			0010-1900
Arbitrary Hyphen:	big-daddy [0200]
Arbitrary No Hyphen:	backwoods [1480]
Note:	sentence fragment quoted [1360-1380]
2,028 words	193 (9.5%) quotes

G09. Selma Jeanne Cohen, "Avant-Garde Choreography"
	Reprinted from Criticism a quarterly for literature and the arts
	vol. III, no.1 (Winter, 1961), 24-28, by permission of the Wayne State
	University Press.			0010-1800
Arbitrary Hyphens:	neo-dadaist [0060]
			front-back [1100]
Typographical Errors:	light color, and sound [1170]
			kaleidescope [1290]
2,011 words	103 (5.1%) quotes

G10. Clarence Streit, "How the Civil War Kept You Sovereign"
	[chapter 8 of Freedom's Frontier--Atlantic Union Now, Published 1961 by
	Harper &amp; Brothers (cloth); Paperback edition from Freedom &amp; Union
	Press, Washington]
	Freedom and Union, 16:2 (February, 1961), 16-18
	Used by permission 			0010-1830
Typographical Error:	reremained [0670]
2,046 words	293 (14.3%) quotes

G11. Frank Oppenheimer, "Science and Fear-- A Discussion of Some Fruits of
Scientific
	Understanding, " The Centennial Review, 5:4 (Fall, 1961), 404-409
	Used by permission 			0010-1780
Typographical Errors:	consitutional [0310]
			determing [1300]
			terrestial [0870]
2,016 words	46 (2.3%) quotes 1 symbol

G12. Tom F. Driver, "Beckett by the Madeleine,"
	Columbia University Forum, 4:3 (Summer, 1961), 21-24
	Used by permission 			0010-1690
2,027 words	878 (43.3%) quotes

G13. Charles Glicksberg, "Sex in Contemporary Literature"
	The Colorado Quarterly, 9: 3 (Winter, 1961), 278-282
	Used by permission.			0010-1780
Arbitrary Hyphen: self-analysis [1440]
Typographical Error: pyschiatrist [1160]
2,005 words	110 (5.5%) quotes

G14. Helen Hooven Santmyer, "There Were Fences"
	The Antioch Review, 21: 1 (Spring, 1961), 26-31
	Used by permission.			0010-1720
2,032 words	42 (2.1%) quotes

G15. Howard Nemerov, "Themes and Methods: The Early Stories of Thomas
	Mann," The Carleton Miscellany, 2: 1 (Winter, 1961), 6-11
	Used by permission			0010-1880
2,082 words	247 (11.9%) quotes

G16. John F. Hayward, "Mimesis and Symbol in the Arts"
	Chicago Review, 15: 1 (Summer, 1961), 94-99
	Used by permission.			0010-1870
2,026 words	28 (1.4%) quotes

G17. Randall Stewart, "A Little History, a Little Honesty: A Southern
	Viewpoint," The Georgia Review, 15: 1 (Spring, 1961), 10-15
	Used by permission.			0010-1870
Typographical Errors: Hound of Heaven
                   . for , [1050]
2,065 words	314 (15.2%) quotes 6 symbols

G18. Charles Wharton Stork, "Verner von Heidenstam"
	American-Scandinavian Review, 49: 1 (March, 1961), 39-43
	Used by permission.			0010-1730
Note: the short poems...is [0610]
2,001 words	297 (14.8%) quotes

G19. R. F. Shaw, "The 'Private Eye'"
	Mainstream, 14: 11 (November, 1961), 44-48
	Used by permission.			0010-1790
Typographical Errors: vioiln [0740]	Whimsey [for Wimsey] [1060] descendents
[1130]
2,003 words	29 (1.4%) quotes

G20. Dan McLachlan, Jr., "Communication Networks and Monitoring"
	Public Opinion Quarterly, xxv: 2 (Summer, 1961), 196-202
	Used by permission.			0010-1820
Note: completeness...provide [0390]
	 range and breadth...has increased [0940]
2,053 words	6 (0.3%) quotes 15 symbols 4 formulas

G21. Brainard Cheney, "Christianity and the Tragic Vision-Utopianism
	USA," The Sewanee Review, LXIX: 4 (Autumn, 1961), 518-524
	Used by permission.			0010-1820
Typographical Errors: of [for, or] [0530]
	                 . for , [0530]
2,001 words	194 (9.7%) quotes 1 symbol

G22. Kenneth Reiner, "Coping with Runaway Technology"
	The Ethical Outlook, XLVII: 3 (May-June, 1961), 91-95
	Used by permission.			0010-1910
Note: to-day's [1670] today [0220, 0330, 0410]
2,024 words	194 (9.6%) quotes

G23. William C. Smith, "Why Fear Ideas?"
	The Personalist, XLII: 2 (Spring, April, 1961), 191-197
	Used by permission.			0010-1830
Arbitrary Hyphens: scientifically-trained [1470]
   	              anti-polio [1480]
	              mud-beplastered [1560]
Note: barnsful [1520]
2,006 words 	46 (2.3%) quotes

G24. Sanchia Thayer, "Personality and Moral Leadership: Operations of
	the Political Mind, "Massachusetts Review, 2: 2, 320-325
	Used by permission.			0010-1810
2,032 words	62 (3.1%) quotes

G25. Stanley Parry, "The Restoration of Tradition"
	Modern Age, 5: 2 (Spring, 1961), 128-131
	Used by permission.			0010-1840
Typographical Error: theoriticians [0170]
Note: liberal-conservative [0030] liberal conservative [1130]
2,007 words	29 (1.4%) quotes

G26. Selma Fraiberg, "Two Modern Incest Heroes"
	Partisan Review, 28: 5-6 (1961), 648-652
	Used by permission.			0010-1710
Note: Oedipal [0410] oedipal [0620, 0800]
2,033 words	20 (1.0%) quotes

G27. Matthew Josephson, "Jean H&eacute;lion: The Return from Abstract Art"
	The Minnesota Review, 1: 3 (April, 1961), 346-350
	Used by permission.			0010-1800
Typographical Error: Three-dimentional [0210]
2,017 words	478 (23.7%) quotes

G28. Arlin Turner, "William Faulkner, Southern Novelist"
	Mississippi Quarterly, 14: 3 (Summer, 1961), 124-128
	Used by permission.			0010-1820
2,006 words	7 (0.3%) quotes

G29. [Anonymous,] "References for the Good Society"
	Manas, XIV: 14 (April 5, 1961), 1-2
	Used by permission.			0010-1760
2,005 words	604 (30.1%) quotes 1 symbol

G30. Norwood Russell Hanson, "Copernican and Keplerian Astronomy"
	Journal of the History of Ideas, 22: 2 (April - June, 1961),
	174-179
	Used by permission.			0010-1980
Typographical Error: abberations [1530] rectlinearly [0590]
Note: nonsystematic [0900] non-systematic [1290]
2,008 words	169 (8.4%) quotes

G31. Irving Fineman, Woman of Valor: The Life of Henrietta Szold
	1860-1945. New York: Simon and Schuster, 1961. Pp. 50-56.
	Used by permission.			0010-1780
2,012 words	380 (18.9%) quotes

G32. Finis Farr, Frank Lloyd Wright.
	New York: Charles Scribner's Sons, 1961. Pp. 182-188.
	Copyright 1961 Finis Farr. Used by permission of Charles Scribner's
	Sons.			0010-1730
Typographical Error: harrassment [1510]
2,013 word	445 (22.1%) quotes

G33. Virgilia Peterson, A Matter of Life and Death.
	New York: Atheneum, 1961. Pp. 72-78.
Typographical Error: transcondant [0500]
Used by permission.			0010-1680
2,052 words	26 (1.3%) quotes

G34. Harry Golden, Carl Sandburg.
	New York and Cleveland: The World Publishing Company, 1961. Pp.
	82-87.
	Copyright 1961. Used by permission of The World Publishing Company.
	0010-1840
Typographical Error (within quotation): guerilla [1810]
2,001 words	554 (27.7%) quotes 4 symbols

G35. Dwight D. Eisenhower, Peace with Justice.
	New York: Columbia University Press, 1961. Pp. 210-217.
	Used by permission.			0010-1920
2,057 words

G36. DeWitt Copp and Marshall Peck, Betrayal at the UN: the story of
	Paul Bang-Jensen. New York: The Devin-Adair Company, 1961.
	Pp. 208-215.
	Used by permission.			0010-1880
Arbitrary Hyphen: wind-swept [0180]
2,012 words	1271 (63.2%) quotes

G37. Gordon Langley Hall, Golden Boats from Burma.
	Philadelphia: Macrae-Smith Company, 1961. Pp. 56-64.
	Used by permission.			0010-1760
Note: Hooghli [1020] Hoogli [quoted, 1090]
2,010 words	387 (19.3%) quotes

G38. Bertrand A. Goldgar, The Curse of Party: Swift's Relations with
	Addison and Steele. Lincoln: University of Nebraska Press,
	1961. Pp. 140-145.
	Used by permission.			0010-1820
Note: Eighteenth Century spelling and punctuation in quotations.
2,010 words	264 (13.1%) quotes

G39. Edward Jablonski, Harold Arlen Happy with the Blues.
	New York: Doubleday &amp; Company, Inc., 1961. Pp. 132-137.
	Used by permission.			0010-1870
Typographical Errors: expressivness [0480]
	                 monacle [for monocle] [0900, 0930, 0950, 0960, 0980]
2,055 words	463 (22.5%) quotes

G40. Gene Fowler, Skyline: A Reporter's Reminiscences of the 1920s.
	New York: Viking Press, 1961. Pp. 170-175.
	Used by permission.			0010-1750
2,007 words	199 (9.9%) quotes

G41. Lillian Rogers Parks and Frances S. Leighton, My Thirty Years
	Backstairs at the White House. New York: Fleet Publishing
	Corp., 1961. Pp. 188-194.
	Used by permission.			0010-1670
2,031 words	40 (2.0%) quotes

G42. Harold D. Lasswell, "Epilogue" to Arnold A. Rogow, Editor,
	The Jew in a Gentile World: an Anthology of Writings About Jews,
	by Non-Jews. New York: The Macmillan Company, 1961. Pp. 374-379.
	Used by permission.			0010-1910
2,031 words	8 (0.4%) quotes

G43. Robert E. Lane, The Liberties of Wit: Humanism, Criticism, and
	the Civil Mind. New Haven: Yale University Press, 1961. Pp.
	112-118.
	Used by permission.			0010-1780
Typographical Error: strategem [1120]
2,004 words	246 (12.3%) quotes

G44. Newton Stallknecht, "Ideas and Literature," in Newton Stallknecht
	and Horst Franz, editors, Comparative Literature: Method and Per-
	spective. Carbondale: Southern Illinois University Press, 1961.
	Pp. 116-123.
	Used by permission.			0010-1840
Typographical Error: roughtly [0470] familarity [1630]
2,009 words	363 (18.1%) quotes 2 symbols

G45. W. A. Swanberg, Citizen Hearst: A Biography of William Randolph
	Hearst. New York: Charles Scribner's Sons, 1961. Pp. 212-216.
	Copyright 1961 by W. A. Swanberg. Used by permission of Charles
	Scribner's Sons.			0010-1830
Arbitrary No Hyphen: bulldoze [0600]
2,054 words	822 (40.0%) quotes

G46. Henry R. Winkler, "George Macaulay Trevelyan," in S. William
	Halperin, editor, Some 20th-Century Historians. Chicago:
	University of Chicago Press, 1961. Pp. 42-49.
	Used by permission.			0010-1870
2,006 words	112 (5.6%) quotes

G47. Garry Davis, The World Is My Country.
	New York: G. P. Putnam's Sons, 1961. Pp. 92-97.
	Used by permission.			0010-1790
Note: Peters corrected to Peter [1090, 1100, 1130]
2,004 words	568 (28.3%) quotes

G48. Francis F. McKinney, Education in Violence: The Life of George H.
	Thomas and the History of the Army of the Cumberland. Detroit:
	Wayne State University Press, 1961. Pp. 362-366.
	Copyright Francis F. McKinney. Used by permission. 0010-1780
Typographical Error: reconnaissanace [0330]
2,008 words	26 (1.3%) quotes 1 symbol

G49. Paul van Kuykendall Thomson, Francis Thompson, A Critical Biography.
	New York. Thomas Nelson &amp; Sons, 1961. Pp. 172-178.
	Used by permission.			0010-1840
2,109 words	738 (35.0%) quotes

G50. Curtis Carroll Davis, The King's Chevalier: A Biography of Lewis
	Littlepage. Indianapolis: The Bobbs-Merrill Co., A Subsidiary
	of Howard W. Sams &amp; Co., Inc., 1961. Pp. 192-196.
	Used by permission.			0010-1840
Typographical Errors: far [for for] [0620] baragining [1630]
	                 year's [for years] [0580]
2,032 words	162 (8.0%) quotes 1 symbol

G51. Ilka Chase, The Carthaginian Rose.
	Garden City, New York: Doubleday &amp; Company, Inc., 1961.
	Pp. 182-186.
	Used by permission.			0010-1730
2,000 words	66 (3.3%) quotes

G52. Robert L. Duncan, The Reluctant General.
	New York: E. P. Dutton &amp; Co., Inc., 1961. Pp. 70-74.
	Copyright 1961 by Robert Lipscomb Duncan. Used by permission of
	E. P. Dutton &amp; Co., Inc.			0010-1800
2,032 words	269 (13.2%) quotes

G53. Bertram Lippincott, Indians, Privateers, and High Society.
	Philadelphia: J. B. Lippincott Co., Pp. 50-56.
	Used by permission.			0010-1790
Note: Indian names; seventeenth century language in quotations
2,006 words	558 (27.8%) quotes

G54. Mabel Wolfe Wheaton and LeGette Blythe, Thomas Wolfe and His
	Family. Garden City, New York: Doubleday &amp; Company, Inc.,
	1961. Pp. 202-207.
	Copyright 1961 by Doubleday &amp; Company, Inc., Reprinted by permission
	of the publisher.			0010-1710
Typographical Error: Carneigie [0740]
2,022 words	188 (9.3%) quotes

G55. Ralph Flanders, Senator from Vermont.
	Boston: Little, Brown &amp; Co., 1961. Pp. 124-129.
	Copyright 1961 by Ralph E. Flanders. Used by permission. 0010-1710
2,009 words	219 (10.9%) quotes 2 symbols 2 formulas

G56. Keith F. McKean, The Moral Measure of Literature.
	Denver: Alan Swallow, 1961. Pp. 16-22.
	Copyright 1961 by Keith McKean. Used by permission.	0010-1730
Note: Sixteenth century words in quotations and titles
2,017 words	140 (6.9%) quotes

G57. Robin M. Williams, Jr., "Values and Modern Education in the
	United States," in Donald N. Barrett, editor, Values in
	America. Notre Dame, Indiana: The University of Notre Dame
	Press, 1961. Pp. 74-80.			0010-1980
	Used by permission.
Typographical Error: profoundity [1800]
2,051 words	42 (2.0%) quotes

G58. North Callahan, Daniel Morgan.
	New York: Holt, Rinehart and Winston, Inc., 1961. Pp. 154-160.
	Copyright 1961 by North Callahan. Reproduced by permission
	of Holt, Rinehart and Winston, Inc.		0010-1820
2,019 words	347 (17.2%) quotes

G59. Esther Rowland Clifford, A Knight of Great Renown.
	Chicago: The University of Chicago Press, 1961. Pp. 160-166.
	Used by permission.			0010-1840
Arbitrary Non-Hyphen: evermounting [0990]
Note: French, Italian and Latin words
2,101 words	105 (5.0%) quotes

G60. Gertrude Berg and Cherney Berg, Molly and Me.
	New York: McGraw-Hill Book Company. Inc., 1961. Pp. 134-139.
	Copyright 1961 by Cherney Berg. Used by permission.	0010-1610
Note: whyfores [0900]
2,009 words	20 (1.0%) quotes

G61. Donald A. White, Litus Saxonicum
	Madison, Wisconsin: Department of History, University of
	Wisconsin, 1961.
	Used by permission.			0010-1930
Note: it is this...which are [0360-0370]
Typographical Errors: preceeding [0020,1600], missing [1170]
	                 word missing [0350], complection [1610]
	                 no final " [0710], aujourd 'hui [0570]
	                 whose [1010], phenonenon [1680]
2,038 words	182 (8.9%) quotes

G62. C. H. Cramer, Newton D. Baker.
	Cleveland: The World Publishing Company, 1961. Pp. 96-102.
	Copyright 1961 by C. H. Cramer. Reprinted by permission of
	The World Publishing Company.			0010-1890
2,031 words	217 (10.7%) quotes 6 symbols

G63. George Steiner, The Death of Tragedy.
	New York: Alfred A. Knopf, 1961. Pp. 192-200.
	Used by permission.			0010-1800
Typographical Errors: it [for is] [0220] breath [for breathe] [1450]
2,007 words	7 (0.3%) quotes

G64. Mark Eccles, Shakespeare in Warwickshire.
	Madison: University of Wisconsin Press, 1961. Pp. 94-99.
	Used by permission.			0010-1740
Note: Elizabethan spelling in quotations
2,055 words	853 (41.5%) quotes 1 symbol 15 formulas

G65. Timothy Paul Donovan, Henry Adams and Brooks Adams.
	Norman: The University of Oklahoma Press, 1961. Pp. 72-78.
	Copyright by The University of Oklahoma Press. Used by permission. 0010-1880
2,034 words	203 (10.0%) quotes

G66. Van Wyck Brooks, From the Shadow of the Mountain.
	New York: E. P. Dutton &amp; Co., Inc., 1961. Pp. 98-103.
	Copyright 1961 by Van Wyck Brooks. Used by permission of E. P.
	Dutton &amp; Co., Inc.			0010-1730
	Arbitrary Hyphen: fellow-creatures [0880]
2,031 words	241 (11.9%) quotes

G67. Mark Schorer, Sinclair Lewis: An American Life.
	New York: McGraw-Hill Book Company, Inc., 1961. Pp. 468-472.
	Copyright 1961 by Mark Schorer. Used by permission.	0010-1770
2,085 words	231 (11.1%) quotes 1 symbol

G68. Harris Francis Fletcher, The Intellectual Development of John
	Milton. Volume II. Urbana, Illinois: The University of Illinois
	Press, 1961. Pp. 474-478.
	Copyright 1961 by Board of Trustees of University of Illinois.
	Used by permission.			0010-1830
Note: Many Latin titles
2,075 words	2 (0.1%) quotes 2 symbols

G69. Mark R. Hillegas, "Dystopian Science Fiction: New Index to the
	Human Situation," New Mexico Quarterly, 31: 3 (Autumn, 1961),
	240-245.
	Used by permission.			0010-2020
Note: Frederick [0670] Frederik [0810]
2,074 words	204 (9.8%) quotes

G70. Joseph Wood Krutch, "If You Don't Mind My Saying So"
	The American Scholar, 31: 1 (Winter, 1961-1962), 120, 122, 124.
	Used by permission.			0010-1690
Arbitrary Hyphen: weasel-worded [1020]
2,006 words	165 (8.2%) quotes

G71. Joseph Frank, "Andr&eacute; Malraux: The Image of Man"
	The Hudson Review, 14:1 (Spring, 1961), 52-57.
	Used by permission.			0010-1800
2,010 words	338 (16.8%) quotes

G72. J. W. Fulbright, "For a Concert of Free Nations"
	Foreign Affairs, 40: 1 (October, 1961), 12-17.
	Used by permission.			0010-1890
2,018 words	226 (11.2%) quotes 10 symbols

G73. Carolyn See, "The Jazz Musician as Patchen's Hero"
	The Arizona Quarterly, 17: 2 (Summer, 1961), 136-141.
	Used by permission.			0010-1840
Arbitrary No Hyphen: longtime [0160]
Typographical Errors: likes [for like] [1680] missing apostrophe [1700]
2,036 words	226 (11.1%) quotes 1 symbol

G74. John McCormick, "The Confessions of Jean Jacques Krim"
	The Noble Savage, 4 (October, 1961), 8-12.
	Used by permission.			0010-1910
Arbitrary Hyphen: mid-thirties [1230]
2,018 words	349 (17.3%) quotes 1 symbol

G75. George Garrett, "A Wreath for Garibaldi"
	The Kenyon Review, 23: 3 (Summer, 1961), 484-489.
	Used by permission.			0010-1680
Typographical Error: highpoint [0530]
2,003 words	42 (2.1%) quotes 1 symbol
<hr><hr>

H. MISCELLANEOUS: GOVERNMENT &amp; HOUSE ORGANS


H01. Handbook of Federal Aids to Communities. U.S. Department of
	Commerce, Area Development Administration, June, 1961. Pp. 10-13. 0010-2160
Note: excerpt ends with a colon
Typographical Errors: ,misplaced [0440] provdied [1670]
2,071 words	7 (0.3%) quotes 32 symbols

H02. An Act for International Development, A Summary Presentation.
	June, 1961. Department of State, U.S.A., Pp. 12-17.	0010-2020
Note: ellipsis used ornamentally
2,134 words

H03. 87th Congress, 1st Session. House Document No. 247. The
	Leadership of Speaker Sam Rayburn. Collected Tributes of His
	Congressional Colleagues. A compilation of tributes paid him in
	the Hall of the House of Representatives, June 12, 1961. Pp. 60-65.
0010-1740
2,022 words	16 (0.8%) quotes

H04. Rhode Island Legislative Council. Research Report Number 1,
	1961. State Automobiles and Travel Allowances. Pp. vii-x, 1-8.
Typographical Error: reimburseable [0560, 0600]	0010-1980
2,062 words	286 (13.9%) quotes

H05. Rhode Island Legislative Council. Research Report Number 4,
	1961. Taxing of Movable Tangible Property. Pp. 5-15.	0010-1820
2,029 words	230 (11.3%) quotes

H06. Rhode Island Development Council. Annual Report 1960. Pp. 4-11.
0010-2160
Typographical Errors: no final " [1460] Metropolian [1560] . for , [1130]
2,132 words	125 (5.8%) quotes

H07. Rhode Island Legislative Council. Research Report Number 2,
	1961. Uniform Fiscal Year for Municipalities. Pp. 11-25. 0010-1990
Arbitrary Hyphen: change-over [1120]
Typographical Errors: to missing [0020] actual actual [0970]
2,114 words	2 (0.1%) quotes

H08. Rhode Island Governor's Proclamations:
	A. R. I. Heritage Week, April 29-May 7, 1961	0010-0280
	B. Armed Forces Day, May 20, 1961		0290-0540
	C. National Maritime Day, May 22, 1961		0550-0780
	D. Miss R. I. Pageant Week, June 11-17, 1961	0790-1040
	E. United Nations Day, October 24, 1961		1050-1240
	F. The State Ballet of R. I. Week, 
		November 13, 1961 ff.			1250-1500
	G. Thanksgiving Day, November 23, 1961		1510-1880
Typographical Error: Notte, Jr [0010] on for of [0270]
2,048 words	34 (1.7%) quotes

H09. Statements 87th Congress, 1st Session. Appropriations, Budget
	Estimates, etc. Public Laws 87-295, H. R. 7916; 87-300, H. R.
	8341; 87-347, H. R. 84. January 13, 1961 - September 27, 1961.
	Pp. 410-414.			0010-1990
2,108 words	2 (0.1%) quotes 3 symbols

H10. Medicine in National Defense. Final Report of the Assistant
	Secretary of Defense (Health and Medical). 1 July 1958 - 31 
	January 1961 (dated 22 November 1961). Washington 25, D.C.
	Pp. 68-72.			0010-2130
2,030 words	42 (2.1%) quotes 4 symbols

H11. 1961 Research Highlights of the National Bureau of Standards.
	Annual Report, Fiscal Year 1961. U.S. Department of Commerce,
	Miscellaneous Publication 242, December, 1961. Pp. 54-60.
Note: 21 cm. [0400] 21-cm. [0510]			0010-2010
2,044	2 (0.1%) quotes 20 symbols 22 formulas

H12. Legislation on Foreign Relations. Committee on Foreign Relations,
	U.S. Senate. Committee on Foreign Affairs, U.S. House of
	Representatives. December, 1960. Pp. 480-483. 	0010-1920
Typographical Error: provisons [0610]
2,130 words	10 symbols

H13. 87th Congress, 1st Session. Congressional Record. Vol. 102,
	Part 6. May 1 to May 17, 1961. Pp. 7019-7020.
	A. Extension of Remarks of Hon. Edwin B. Dooley, "Computer
	   Railroads"						0010-0710
	B. Extension of Remarks of Hon. John V. Lindsay, "Tribute
	   to Retiring Publisher Arthur Hays Sulzberger and
	   Editorial Page Editor Charles Merz, 
	   of the New York Times"				0720-0960
	C. Extension of Remarks of Hon. Samuel S. Stratton, "Naval
	   Blockade of Cuba"					0970-1970
Arbitrary Hyphen: two-system [0570]
Typographical Errors: . [for,][1550] to [for the] [1840]
2,134 words	1,235 (57.9%) quotes 2 symbols

H14. Grants-in-Aid and Other Financial Assistance Programs
	Administered by the U.S. Department of Health, Education and
	Welfare.
	Office of Program Analysis. 1961 Edition. Pp. 157-162.
Typographical Error: apostrophe missing [1510]	0010-1950
2,073	41 (2.0%) quotes 3 symbols

H15. The Family Fallout Shelter. Office of Civil and Defence
	Mobilization. M. P. 15. Pp. 9-19.		0010-1900
2,061 words	1 (0.0%) quote 3 symbols

H16. U.S. Reports. Volume 366. Cases Adjudged in the Supreme Court
	at October Term 1960. Opinions and Decisions Per Curiam April
	24 through (in part) June 5, 1961. Pp. 338-345.	0010-1960
2,104 words	538 (25.6%) quotes

H17. U.S. Reports. Volume 364. Cases Adjudged in the Supreme Court
	October Term 1959, 1960, August Special Term 1960. Pp. 58-65.
2,243 words	144 (6.4%) 10 symbols	0010-2050

H18. The Department of State: A Fresh Look at the Formulation of
	Foreign Policy. Informal Remarks made by Secretary of State
	Rusk...February 20, 1961. Pp. 2-4.		0010-1770
2,048 words	15 (0.7%) quotes

H19. Peace Corps. Fact Book. April 1, 1961. Pp. 20-25.	0010-1840
Typographical Error: extra and [0470]
2,014 words	17 (0.8%) quotes 2 symbols

H20. Development Program for the National Forests. U.S. Department
	of Agriculture. Forest Service. November, 1961. Miscellaneous
	Publication 896. Pp. 14-20.			0010-2080
Typographical Error: additions to its that are needed [1260]
Note: dwarfmistletoe [0740]
2,169 words

H21. Public Papers of the Presidents of the U.S. D. D. Eisenhower,
	1960-1961. Containing the Public Messages, Speeches and
	Statements of the President, January 1, 1960 to January 20, 1961. Pp. 48-53.
0010-1980
Arbitrary Hyphen: break-through [1200]
2,085 words	16 symbols

H22. U.S. Treaties and Other International Agreements. Volume II,
	Part 2. 1960. 1307-2695, Department of State. Pp. 1546-1551.
2,276 words	32 symbols	0010-2140

H23. Federal Communications Commission Reports. Decisions and Reports
	of the Federal Communications Commission of the United States,
	July 10, 1959, to January 8, 1960. Vol. 27. Pp. 588-592.
Typographical Errors: whereever [1330]		0010-1940
	                 intereference [1940]
2,029 words	3 (0.1) quotes 20 symbols

H24. Your Federal Income Tax. 1962 Edition (Revised to October 1961)
	U.S. Treasury Department, Internal Revenue Service. Publication
	No. 17. Pp. 11-13.			0010-1890
2,201 words	5 symbols

H25. "Report of the Secretary General" in John Simon Guggenheim
	Memorial Foundation, Reports of the Secretary General and of 
	the Treasurer, 1959 and 1960. New York: 1961. Pp. 16-24.
	Used by permission.			0010-1850
2,013 words	41 (2.0%) quotes

H26. [Anonymous,] A Brief Background of Brown &amp; Sharpe Past Present
	8-page pamphlet, no date.
	Used by permission.			0010-1880
Note: metalworking [0070] metal-working [1760]
Typographical Error: superceded [1100]
2,004 words	20 (1.0%) quotes

H27. Annual Report for the year ended December 31, 1960. Leesona
	Corporation, Providence, Rhode Island. Used by permission.
	A. Pp. 2-5 "President's Report to Stockholder and Employees"
	   by Robert Leeson, President			0010-1780
	B. P. 6 "More Efficient Production for Expanding
	   Textile Markets"			1790-1970
Typographical Errors: bobin-to-cone [0760] transfered [1500]
2,051 words	3 (0.1%) quotes 4 symbols

H28. Carleton College Bulletin. Northfield, Minnesota: March, 1961.
	Pp. 92-99. Used by permission.			0010-2090
2,032 words	39 (1.9%) quotes 3 symbols

H29. Sprague Log, xxiii: 5 (January, 1961). Sprague Electric Company,
	North Adams, Massachusetts. Used by permission.
	A. Pp. 1,9 "R. C. Sprague Predicts Further Gain for
	   Electronics Industry"				0010-1400
	B. P. 1 "Gilbert B. Devey Named General Manager of
	   Vectrol Engineering"					1410-1830
	C. P. 1 "Swift &amp; Garlington Assume Additional 
	   Duties In ICFS Dept."				1840-1900
Arbitrary Hyphens: well-informed [0620] English-born [1690]
                   semi-conductors [1280] electro-magnetic [1890]
Typographical Error: compatability [1900]
2,037 words	8 symbols

H30. Fifty-sixth Annual Report for the Year ending June 30, 1961. The
	Carnegie Foundation for the Advancement of Teaching. [Summary from
	Harold W. Dodds, The College and University President at Work.] Pp. 18-24.
	Used by permission.			0010-1940
2,003 words	15 (0.7%) quotes
<hr><hr>

J. LEARNED


J01. Cornell H. Mayer, "Radio Emission of the Moon and Planets" in
	Gerard P. Kuiper and Barbara M. Middlehurst, editors, Planets
	and Satellites. Vol. 3 of The Solar System. Chicago: The
	University of Chicago Press, 1961. Pp. 442-446.
	Copyright 1961 by The University of Chicago Press. Used by permission.
0010-1930
2,000 words	30 symbols 1 formula

J02. Raymond C. Binder et al., editors, Proceedings of the 1961 Heat
	Transfer and Fluid Mechanics Institute. Stanford: Stanford
	University Press, 1961. Pp. 193-196.
	Copyright 1961 by the Board of Trustees of the Leland Stanford Junior
	University. Used by permission of the Stanford University Press. 0010-1830
Typographical Error: tothe [1040]
2,017 words	9 symbols 23 formulas

J03. Harry H. Hull, "The Normal Forces and Their Thermodynamic Significance,"
	Transactions of the Society of Rheology, V (1961), 120-125.
	Used by permission.			0010-1750
Typographical Error: as [for is] [0570]
2,023 words	15 (0.7%) quotes 25 symbols 28 formulas

J04. James A. Ibers et al., "Proton magnetic resonance study of
	polycrystalline HCr02" The Physical Review, 121: 6 (March 15, 1961),
	1620-1622. Used by permission.		0010-1990
Typographical Error: electron [for electrons] [1370]
2,103 words	6 (0.3%) quotes 37 symbols 90 formulas

J05. Jay C. Harris and John R. Van Wazer, "Detergent building", in J. R.
	Van Wazer, editor, Phosphorus and Its Compounds.
	New York: Interscience Publishers, Inc., 1961. Pp. 1732-1737.
	Used by permission.			0010-1940
Typographical Error: a [for an] [1670]
2,036 words	4 (0.2%) quotes 3 formulas

J06. Francis J. Johnston and John E. Willard, "The exchange reaction
	between Chlorine and Carbon Tetrachloride", Journal of Physical
	Chemistry, 65 (February, 1961, 317-318.
	Copyright 1961 by American Chemical Society. Used by permission. 0010-1830
2,020 words	1 symbol 32 formulas

J07. J. F. Vedder, "Micrometeorites", in Francis S. Johnson, editor,
	Satellite Environment Handbook. Stanford: Stanford University
	Press, 1961. Pp. 92-97.
	Copyright 1961 Lockheed Aircraft Corp., Missiles &amp; Space Div., Palo
Alto,
	California. Used by permission.		0010-1940
2,134 words	1 (0.0%) quote 9 symbols 25 formulas

J08. LeRoy Fothergill, "Biological Warfare", in Peter Gray, editor,
	The Encyclopedia of the Biological Science. New York: Reinhold
	Publishing Corporation, 1961. Pp. 145-149.
	Used by permission.			0010-1880
Typographical Errors: areosol [0170] . [for ,] [0560]
	                 assesment [0270] on-sure [for on-shore] [0860]
	                 meterological [0440]
2,003 words	2 (0.1%) quotes 10 symbols 3 formulas

J09. M. Yokoyama et al., "Chemical and serological characteristics
	of blood group antibodies in the ABO and Rh systems," The
	Journal of Immunology, 87 (1961), 56-60.
	Used by permission.			0010-1940
Note: Abbreviations without period (min hr ml) treated as symbols
Typographical Error: used [for use] [0600]
2,027 words	10 (0.5%) quotes 93 symbols 19 formulas

J10. B. J. D. Meeuse, The Story of Pollination.
	New York: The Ronald Press Company, 1961. Pp. 104-108.
	Copyright 1961 The Ronald Press Company. Used by permission.	0010-1720
2,004 words	11 (0.5%) quotes 1 symbol

J11. Clifford H. Pope, The Giant Snakes.
	New York: Alfred A. Knopf, 1961. Pp. 150-155.
	Used by permission.			0010-1790
2,015 words	21 (1.0%) quotes

J12. Richard F. McLaughlin, et al., "A study of the subgross pulmonary
	anatomy in various mammals," The American Journal of Anatomy,
	108 (1961), 154-157. Used by permission.	0010-1890
2,011 words

J13. S. Idell Pyle, et al., Onsets, Completions, and Spans of the Osseous
	Stage of Development in Representative Bone Growth Centers of the
	Extremities. Longitudinal Studies of Child Health and Development,
	Harvard School of Public Health, Series II, No. 12. Monograph of the
	Society for Research in Child Development, 26: 1. Serial No. 79, 1961.
	Pp. 20-21, 24-25.
	Used by permission of the Society for Research in Child Development
	and the senior author.			0010-1790
	Typographical Error: , missing [1590]
2,022 words	41 (2.0%) quotes

J14. Jacob Robbins et al., "The thyroid-stimulating hormone and the
	iodine-containing hormones," in C. H. Gray and A. L. Bacharach,
	editors, Hormones in Blood.
	London and New York: Academic Press, 1961. Pp.52-56
	Used by permission:			0010-1959
2,018 words	28 symbols, 6 formulas

J15. J. W. C. Hagstrom et al., "Debilitating muscular weakness and
	steroid therapy," Archives of Neurology, 5 (1961), 60-65.
	Used by permission of American Medical Association.
Typographical Error: 1949 [for 1959] [0640]	0010-1950
2,013 words	13 (0.6%) quotes 2 symbols 1 formula

J16. A. N. Nagaraj and L. M. Black, "Localization of wound-tumor
	virus antigen in plant tumors by the use of fluorescent antibodies,"
	Virology, 15 (1961), 290-293.
	New York: Academic Press, Used by permission.	0010-2010
2,012 words	53 symbols 52 formulas

J17. E. Gellhorn, "Prolegomena to a theory of the emotions"
	Perspectives in Biology and Medicine, 4 (1961), 426-431.
	Chicago: The University of Chicago Press. Used by permission.	0010-2120
Typographical Error: parsympathetic [1210]	
2,078 words	6 (0.3%) quotes 6 symbols

J18. Kenneth Hoffman and Ray Kunze, Linear Algebra.
	Englewood Cliffs, New Jersey: Prentice-Hall, Inc., 1961. Pp. 179-185.
	Copyright 1961 by Prentice-Hall, Used by permission.	0010-1780
2,012 words	136 symbols 161 formulas

J19. Frederick Mosteller et al., Probability with Statistical Applications. 
	Reading, Massachusetts: Addison-Wesley Publishing Co.,
	Inc., 1961. Copyright 1961 Addison-Wesley Publishing Co.
	Inc. Used by permission. Pp. 241-245.		0010-1860
1,985 words	45 (2.3%) quotes 31 symbols 22 formulas

J20. R. P. Jerrard, "Inscribed squares in plane curves"
	Transactions of the American Mathematical Society, 98 (1961)
	234-238. Copyright American Mathematical Society, All Rights Reserved.
	Reprinted by permission from the Transactions.
Note: namely [0460] namely, [0970]			0010-1770
	 the analyticity...guarantee [1180]
2,001 words	148 symbols 83 formulas

J21. C. R. Wylie, Jr. "Line involutions in S3 whose singular lines
	all meet in a twisted curve," Proceedings of the American
	Mathematical Society, 12 (1961), 335-339. Copyright American
	Mathematical Society, All Rights Reserved. Reprinted by
	permission from the Proceedings.
Typographical Errors: meets [for meet] [0250]	0010-1700
	                 comma missing [0880]
2,017 words	126 symbols 90 formulas

J22. Max F. Millikan and Donald L. M. Blackmer, editors, The Emerging 
	Nations: Their Growth and United States Policy. Boston: Little,
	Brown and Company, 1961. Pp. 136-142.
	Copyright Massachusetts Institute of Technology. Used by permission.
0010-1930
2,012 words

J23. Joyce O. Hertzler, American Social Institutions; a Sociological
	Analysis. Boston: Allyn and Bacon, Inc., 1961. Pp. 478-482.
	Used by permission.			0010-2090
Typographical Error: humilation [0770]
2,022 words	73 (3.6%) quotes

J24. Howard J. Parad, "Preventive casework: problems and implications"
	The Social Welfare Forum, 1961. New York and London: Columbia
	University Press for the National Conference on Social Welfare,
	Columbus, Ohio. Pp. 186-191.
	Used by permission.			0010-2010
2,009 words	75 (3.7%) quotes

J25. Sister Claire Marie Sawyer, Some Aspects of the Fertility of a
	Tri-Racial Isolate. Washington: The Catholic University of
	America Press, 1961. Studies of Sociology, Number 46. Pp. 8-17.
	Used by permission.			0010-1960
Typographical Error: Final " missing [1960]
2,038 words	437 (21.4%) quotes

J26. Frank Lorimer, Demographic Information on Tropical Africa.
	Boston: Boston University Press, 1961. Pp. 130-136.
	Used by permission.			0010-1980
Note: Bibliographical references omitted, replaced by **B.
1,997 words	10 symbols 2 formulas

J27. Dale L. Womble, "Functional Marriage Course for the Already
	Married", Marriage and Family Living, 23 (1961), 280-282.
	Used by permission of author and editor.	0010-1800
Typographical Error: examiantion [1780]
2,015 words	104 (5.2%) quotes

J28. William H. Ittelson and Samuel B. Kutash, editors, Perceptual
	Changes in Psychopathology. New Brunswick, New Jersey: Rutgers
	University Press, 1961. Pp. 196-201.
	Used by permission.			0010-1930
2,025 words	95 (4.7%) quotes 11 symbols 1 formula

J29. Jesse W. Grimes and Wesley Allinsmith, "Compulsivity, Anxiety
	and School Achievement", Merrill-Palmer Quarterly of Behavior and
	Development, 7 (1961), 254-261.
	Used by permission.			0010-1950
Typographical Errors: underachievers [0250] multiphastic [0650]
2,039 words	29 (1.4%) quotes 1 symbol 5 formulas

J30. Raymond J. Corsini et al., Roleplaying in Business and Industry.
	New York: Free Press of Glencoe, Inc., A Division of the Crowell-
	Collier Publishing Company, 1961. Pp. 138-146.
	Used by permission.			0010-1790
Note: check list [1280] checklist [1420]
Typographical Error: possiblities [0130]
2,018 words	38 (1.9%) quotes 1 formula

J31. Harold Searles, "Schizophrenic Communication," Psychoanalysis
	and the Psychoanalytic Review, 48 (1961), 14-18.
	Reprinted from Psychoanalysis and the Psychoanalytic Review
	(now known as The Psychoanalytic Review), Volume 48, No. 1,
	Spring 1961, through the courtesy of the Editors and the Publisher,
	National Psychological Association for Psychoanalysis, Inc.	0010-1790
Typographical Errors: steoreotyped [0650] smile [for simile] [1670]
	                 suffered [for sufferer] [0770]
	                 one [for One] [1010] women [for woman] [1700]
2,015 words	89 (4.4%) quotes

J32. Hugh Kelly and Ted Ziehe, "Glossary Lookup Made Easy"
	Proceedings of the National Symposium on Machine Translation,
	University of California at Los Angeles. Englewood Cliffs,
	New Jersey: Prentice-Hall, Inc., 1961. Pp. 326-331. Reproduction
	permitted for any purpose of the U.S. Government.	0010-1750
Typographical Error: voume [0050] give [for gives] [0390]
1,990 words	21 symbols 48 formulas

J33. Ralph B. Long. The Sentence and Its Parts: A Grammar of Contemporary
	English. Chicago: The University of Chicago Press, 1961.
	Pp. 460-464. Copyright 1961 by The University of Chicago
	Press. Used by permission.			0010-1800
2,019 words	25 (1.2%) quotes 3 symbols

J34. H. A. Gleason, "Review of African language studies I, edited by 
	Malcolm Guthrie," Language, 37 (1961), 302-305.
	Used by permission.			0010-1870
Typographical Error: familar [0150]
2,000 words	22 (1.1%) quotes

J35. A.L. Kroeber, "Semantic Contribution of Lexicostatistics"
	International Journal of American Linguistics, 27 (1961), 4-7.
	Used by permission.			0010-1860
2,034 words	22 (1.1%) quotes 10 symbols 12 formulas

J36. D. F. Fleming, The Cold War and Its Origins.
	New York: Doubleday &amp; Company, Inc., 1961. Vol. 1: 1917-1960.
	Pp. 202-205. Reprinted by permission of Doubleday &amp; Company, Inc.
0010-1840
2,025 words	433 (21.4%) quotes

J37. Douglas Ashford, "Elections in Morocco: Progress or Confusion?"
	Middle East Journal, Winter, 1961, 2-8.
	Used by permission.			0010-1950
Arbitrary Hyphen: let-down [0630]
Note: strains...was revealed [0590] estimate...were made [1940]
2,005 words 	28 (1.4%) quotes

J38. Committee for Economic Development, Distressed Areas in a Growing
	Economy. A Statement on National Policy by the Research and Policy
	Committee of the Committee for Economic Development. New York,
	1961. Pp. 48-53. Used by permission.		0010-1920
2,018 words

J39. William O'Connor. Stocks, Wheat and Pharaohs.
	New York: Wener Books Company, 1961. Pp. 82-89.	0010-1820
Note: oversubscribed [1720] over-subscribed [1730]
Typographical Errors: intial [0050] cocao [0510]
	                 good natured [0160] comittment [1690]
2,039 words	115 (5.6%) quotes

J40. James J. O'Leary, "The Outlook for Interest Rates in 1961"
	Banking, LIII (1961), 40-41, 112, 114, 117.
	Copyright American Bankers Association. Used by permission. 0010-1810
Arbitrary Hyphens: clear-cut [1550]
	              home-building [1580]
1,999 words	4 (0.2.%) quotes 1 symbol

J41. Allan J. Braff and Roger F. Miller, "Wage-Price Policies Under
	Public Pressure," Southern Economic Journal, xxviii: 2 (1961),
	163-165. Copyright by Southern Economic Association. 
	Used by permission.			0010-1800
2,024 words	17 (0.8%) quotes 8 symbols

J42. Morton A. Kaplan and Nicholas de B. Katzenbach, The Political
	Foundation of International Law. New York: John Wiley &amp; Sons,
	Inc., 1961. Pp. 62-67. Copyright  by John Wiley &amp; Sons, Inc.
	Used by permission.			0010-1910
Typographical Errors: principle [1690] industralization [1050]
2,032 words	79 (3.9%) quotes

J43. Wallace Mendelson, Justices Black and Frankfurter: Conflict in
	the Court. Chicago: The University of Chicago Press, 1961.
	Pp. 90-96. Copyright The University of Chicago Press.
	Used by permission.			0010-1920
1,998 words	452 (22.6%) quotes 2 symbols

J44. J. Mitchell Reese, Jr., Reorganization Transfers and Survival
	of Tax Attribute," Tax Law Review, 16 (1961), 210-215.
	Copyright New York University School of Law. Used by permission. 0010-1880
Typographical Error: depeciation [0070]
2,026 words	34 (1.7%) quotes 3 symbols

J45. Albert N. Schrieber et al., Defence Procurement and Small
	Business. Seattle: University of Washington Press, 1961.
	Pp. 7-13. Copyright authors. Used by permission.	0010-1910
Arbitrary Hyphen: key-punched [1670]
Note: key punching [1680]
Typographical Error: questionaire [0810]
1,995 words	4 (0.2%) quotes 31 symbols

J46. Irving Perluss, "Agricultural Labor Disputes in California - 1960"
	Employment Security Review, 28: 1 (January, 1961), 5-7.
Typographical Error: sucess [0230]			0010-1870
2,020 words	30 (1.5%) quotes 10 symbols

J47. William B. Ragan, Teaching America's Children.
	New York: Holt, Rinehart and Winston, Inc., 1961. Pp. 76-80.
	Copyright Holt, Rinehart and Winston, Inc., Used by permission.	0010-1860
2,011 words	1 (0.0%) quote

J48. Paul Cooke, "Desegregated Education in the Middle-South Region:
	Problems and Issues," The Journal of Negro Education, 30 (1961)
	75-78. Used by permission.			0010-1950
2,004 words	23 (1.1%) quotes 3 symbols

J49. Robert J. Havighurst, "Social-Class Influence on American Education,"
	chapter V of Social Forces Influencing American Education. The
	Sixtieth Yearbook of the National Society for the Study of
	Education. Edited by Nelson B. Henry. Part II, pp. 130-135.
	Copyright  by The National Study for the Study of Education. Used by
permission.	0010-1920
2,020 words	18 (0.9%) quotes

J50. James C. Bonbright, Principles of Public Utility Rates.
	New York: Columbia University Press, 1961. Pp. 342-347.
	Copyright  Columbia University Press. Used by permission. 0010-1880

2,050 words	62 (3.0%) quotes

J51. Irving Louis Horowitz, Philosophy, Science and the Sociology of
	Knowledge. Springfield, Illinois: Charles C. Thomas, 1961. Pp. 54-59.
	Copyright  Charles C. Thomas. Used by permission.	0010-1900
Arbitrary Hyphen: vantage-points [1050]
2,000 words	13 (0.7%) quotes

J52. Brand Blanshard, "The Emotive Theory," Robert E. Dewey, et al., ed.,
	Problems of Ethics: A Book of Readings. New York: The Macmillan 
	Company, 1961. Pp. 426-429.
	Used by permission.			0010-1600
2,014 words	43 (2.1%) quotes

J53. William S. Haymond, "Is Distance an Original Factor in Vision?"
	The Modern Schoolman, xxxix (1961), 40-45.
	Used by permission.			0010-1760
2,011 words	241 (12.0%) quotes

J54. Chester G. Starr, The Origins of Greek Civilization 1100-650 B. C.
	New York: Alfred A. Knopf, Inc., 1961. Pp. 144-150.
	Copyright Chester G. Starr. Used by permission of Alfred A. Knopf, Inc.
0010-1870
Arbitrary Hyphen: south-eastern [0440]
2,004 words	13 (0.6%) quotes 2 symbols

J55. Jim Berry Pearson, The Maxwell Land Grant.
	Norman: The University of Oklahoma Press, 1961. Pp. 134-139.
	Copyright  The University of Oklahoma Press. Used by permission.  0010-1710
Typographical Error: issue [for issued] [1560]
2,001 words	72 (3.6%) quotes

J56. Edwin L. Bigelow and Nancy H. Otis, Manchester, Vermont: A
	Pleasant Land Among the Mountains. Vermont: The Town of 
	Manchester, 1961. Pp. 108-113.
	 Copyright  The Selectmen. Used by permission.	0010-1900
Arbitrary Hyphen: sub-station [1840]
2,022 words	92 (4.5%) quotes

J57. J. H. Hexter, "Thomas More: On the Margins of Modernity"
	Journal of British Studies, I: 1 (November, 1961), 28-32.
	Used by permission.			0010-1800
Typographical Error: millenium [1260] indispensible [1050]
2,017 words	102 (5.1%) quotes

J58. John Michael Ray, "Rhode Island's Reactions to John Brown's Raid"
	Rhode Island History, 20: 4 (October, 1961), 100-105.
	Used by permission.			0010-1950
Typographical Error: anemated [0780] philantropists [0470] (followed by
[sic])
2,040 words	345 (16.9%) quotes

J59. Clement Greenberg, "Collage" in his Art and Culture: Critical
	Essay. Boston: Beacon Press, 1961. Pp. 74-79.
	Copyright  Clement Greenberg. Used by permission.	0010-1780
2,012 words	4 (0.2%) quotes

J60. Robert A. Futterman, The Future of Our Cities.
	Garden City, New York: Doubleday &amp; Company, Inc., 1961. 
	Pp. 62-68. Copyright  Robert A. Futterman, mail returned ("Deceased")
0010-1850
2,027 words	43 (2.1%) quotes

J61. Allyn Cox, "Completing and Restoring the Capitol Frescos"
	Museum News, 39: 5 (February, 1961), 14-17.
	Copyright  by American Association of Museums. Used by permission. 0010-1780
2,034 words	39 (1.9%) quotes

J62. Jimmy Ernst, "A Letter to Artists of the Soviet Union"
	Art Journal, XXI: 2 (Winter, 1961-62), 66-67.
	Used by permission.			0010-1770
2,021 words	397 (19.6%) quotes

J63. John H. Schaar, Escape from Authority: The Perspective of Erich
	Fromm. New York: Basic Books, Inc., 1961. Pp. 200-207.
	Copyright  Basic Books, Inc. Used by permission.	0010-1890
2,029 words	83 (4.1%) quotes

J64. Katherine Griffith McDonald, "Figures of Rebellion"
	Opera News, 25: 9 (January 7, 1961), 21-23.
	Copyright The Metropolitan Opera Guild, Inc., Used by permission. 0010-1800
2008 words	21 (1.0%) quotes 2 symbols

J65. Samuel Hynes, The Pattern of Hardy's Poetry.
	Chapel Hill: The University of North Carolina Press, 1961. 
	Pp. 130-137. Copyright  Samuel Hynes. Used by permission. 0010-1750
2,011 words	162 (8.1%) quotes

J66. Kenneth Rexroth, "Disengagement: The Art of the Beat Generation" in
	A Casebook of the Beat, edited by Thomas Parkinson. New York:
	Thomas Y. Crowell Company, 1961. Pp. 181-184.
	Used by permission.			0010-1810
Arbitrary Hyphen: by-passes [1330]
Typographical Error: exits [for exists] [1420]
2,005 words	12 (0.6%) quotes

J67. William Whallon, "The Diction of Beowulf"
	PMLA, Publications of the Modern Language Association of America
	LXXVI: 4, part 1 (September, 1961), 309-311.
	Used by permission.			0010-1840
2,013 words	14 (0.7%) quotes

J68. Charles R. Forker, "The Language of Hands in Great Expectations"
	Texas Studies in Literature and Language, III: 2 (Summer, 1961),
	280-284.
	Copyright  The University of Texas Press. Used by their and the
	author's permission.			0010-1870
	2,025 words	320 (15.8%) quotes

J69. IBM Reference Manual - IBM 7070 Series Programming Systems - 
	Autocoder.  Copyright 1961, 1963 by International Business Machines 
	Corporation. Reprinted by permission. Pp. 16-22.	0010-1920
Note: illustration... are [0200]
Typographical Error: or omitted [0460, compare 0490]
2,028 words	23 (1.1%) quotes 79 symbols 1 formula

J70. Ross E. McKinney and Howard Edde, "Aerated Lagoon for Surburban
	Sewage Disposal" Journal of the Water Pollution Control Federation,
	33: 12 (December, 1961), 1277-1283.
	Used by permission.			0010-1870
Typographical Errors: fiberglas [0520] 76-per [0890] 1.0-mg. [1590]
2,022 words	111 symbols

J71. Captain Thomas D. McGrath, USN (Ret'd), "Submarine Defense"
	United States Naval Institute Proceedings, 87: 7 (July, 1961),
	38-41. Copyright  by U.S. Naval Institute. Used by permission.	0010-1980
Note: attacks which is [0640]
2,034 words	2 (0.1%) quotes 3 symbols

J72. "Independent Research" Mellon Institute Annual Report 1960.
	Pittsburgh: Mellon Institute, 1961. Pp. 10-13.
	Copyright  Mellon Institute. Used by permission.	0010-2130
Arbitrary Hyphen: high-voltage [0420]
2,076 words	15 symbols 12 formulas

J73. Directory of Continuing Numeric Data Projects. Washington:
	National Academy of Sciences. National Research Council, 1961.
	Pp. 14-21.			0010-2150
Typographical Error: institute [for Institute] [2040]
2,105 words	6 (0.3%) quotes 2 symbols 4 formulas

J74. Harland W. Nelson, "Food Preservation by Ionizing Radiation"
	Battelle Technical Review, 10: 1 (January, 1961), 8-12.
	Used by permission.			0010-2010
Typographical Errors: comsumer [140] become [for becomes] [1590]
2,039 words	4 (0.2%) quotes 13 symbols

J75. W. K. Asbeck, "Forces in Coatings Removal by Knife Cutting Methods"
	Adhesion and Cohesion, edited by Philip Weiss. New York: Elsevir
	Publishing Company, 1962. Proceedings of the Symposium on Adhesion
	And Cohesion, General Motors Research Laboratories, Warren, Michigan, 1961.
	Pp. 102-103, 105-111.
	Used by permission.			0010-1790
Typographical Error: wil [0170] coatings [for coating's] [0390, 0470, 0870,
1630]
2,034 words	2 (0.1%) quotes 34 symbols 42 formulas

J76. "Survey of foamed plastics" Modern Plastics Encyclopedia, edited by
	Joel Frados. New York: Plastics Catalogue Corporation, 1961.
	Pp. 390-393, of Vol 39, No. 1A.			0010-1940
Arbitrary Hyphens: hydroxyl-rich [0660, 0720] free-blown [1810]
	              air-cell [1160]
Typographical Error: mid [0530]
2,064 words	2 (0.1%) quotes 2 symbols

J77. William D. Appel, editor, 1961 Technical Manual of the American
	Association of Textile Chemists and Colorists. New York: Howes
	Publishing Company, Inc., 1961. Vol. 37 (September, 1961), 121-123.
	Permission to reprint granted by AATCC, Research Triangle Park, 
	P.O.Box 886, Durham, North Carolina.		0010-2030
Arbitrary Hyphen: soil-bearing [0220]
Typographical Error: no final ) [0510]
2,246 words	3 (0.1%) quotes 21 symbols 8 formulas

J78. Paul J. Dolon and Wilfrid F. Niklas, "Gain and Resolution of Fiber Optic
	Intensifier" Proceedings of the Image Intensifier Symposium October 24-26, 
	1961. Washington: Office of Scientific and Technical Information, National
	Aeronautics Space Administration, 1961. Pp. 93-97.		0010-2060
Note: phosphor-screen [0710] phosphor screen [0600, 1550, 1790, 1930, 2030]
2,042 words	6 (0.3%) quotes 33 symbols 44 formulas

J79. Rutherford Aris, The Optical Design of Chemical Reactors.
	New York: Academic Press, Inc., 1961. Pp. 14-20.
	Copyright  Academic Press, Inc. Used by permission.	0010-1750
2,037 words	35 (1.7%) quotes 42 symbols 78 formulas

J80. C. J. Savant et al., Principles of Inertial Navigation.
	New York: McGraw-Hill Book Company, Inc., 1961. Pp. 144-150.
	Copyright  McGraw-Hill Book Company, Inc., Used by permission.	0010-1890
Arbitrary Hyphen: non-linear [0620]
Note: The input axis...are parallel [1700]
2,046 words	24 symbols 16 formulas
<hr><hr>

K: FICTION: GENERAL


K01. Christopher Davis, First Family.
	New York: Coward McCann, Inc., 1961. Pp. 204-210.
	Used by permission of Coward McCann, Inc.	0010-1780
2,009 words	340 (16.9%) quotes

K02. Clayton C. Barbeau, The Ikon.
	New York: Coward McCann, Inc., 1961. Pp. 80-85.
	Used by permission of Clayton Barbeau.	0010-1690
2,004 words	248 (12.4%) quotes 3 symbols

K03. Tristram Coffin, Not to the Swift.
	New York: W. W. Norton &amp; Co., Inc., 1961. Pp. 200-204.
	Used by permission of Tristram Coffin.	0010-1650
2,012 words	999 (49.7%) quotes 1 symbol

K04. W. E. B. DuBois, Worlds of Color.
	New York: Mainstream Publishers, 1961. Pp. 134-139.
	Used by permission of Mainstream Publishers.	0010-1700
2,013 words	243 (12.1%) quotes

K05. David Stacton, The Judges of the Secret Court.
	New York: Pantheon Books, Inc., 1961. Pp. 50-56.
	Used by permission of David Stacton.		0010-1660
2,008 words	38 (1.9%) quotes

K06. Louis Zara, Dark Rider.
	Cleveland, Ohio: World Publishing Company, 1961. Pp. 40-44.
	Used by permission of Louis Zara.		0010-1830
2,059 words 	228 (11.1%) quotes

K07. Francis Pollini, Night.
	Boston: Houghton Mifflin Company, 1961. Pp. 246-252.
	Used by permission of Francis Pollini.	0010-1700
2,005 words	119 (5.9%) quotes 1 symbol

K08. Guy Endore, Voltaire! Voltaire!
	New York: Simon and Schuster, 1961. Pp. 96-100
	Used by permission of Guy Endore.		0010-1750
2,011 words	327 (16.3%) quotes

K09. Howard Fast, April Morning.
	New York: Crown Publishers, Inc., 1961. Pp. 130-136.
	Used by permission of Howard Fast.		0010-1590
2,011 words	92 (4.6%) quotes

K10. Glayds H. Barr, The Master of Geneva.
	New York: Holt, Rinehart and Winston, Inc., 1961. Pp. 152-157.
	Used by permission of Gladys H. Barr.		0010-1750
2,014 words	484 (24.0%) quotes

K11. Robert Penn Warren, Wilderness.
	New York: Random House, 1961. Pp. 162-170.
	Used by permission of Random House, Inc., and R. P. Warren.	0010-1670
2,001 words	230 (11.5%) quotes

K12. Gerald Green, The Heartless Light.
	New York: Charles Scribner's Sons, 1961. Pp. 166-170.
	Used by permission of Gerald Green.		0010-1800
2,019 words	203 (10.1%) quotes 2 symbols

K13. William Maxwell, The Chateau.
	New York: Alfred A. Knopf, Inc., 1961. Pp. 240-245.
	Used by permission of Alfred A. Knopf, Inc.	0010-1690
2,004 words	254 (12.7%) quotes 3 symbols

K14. Irving Stone, The Agony and the Ecstasy.
	Garden City, New York: Doubleday &amp; Company, Inc., 1961.
	Pp. 294-298. Used by permission of Irving J. Stone.	0010-1740
2,023 words	223 (11.2%) quotes

K15. Ann Hebson, The Lattimer Legend.
	New York: The Macmillan Company, 1961. Pp. 190-195.
	Used by permission of The Macmillan Company.	0010-1760
Note: apostrophe missing in Harpers Ferry [0460, 0940]
2,005 words	391 (19.5%) quotes 1 symbol

K16. Stephen Longstreet, Eagles Where I Walk.
	Garden City, New York: Doubleday &amp; Company, Inc., 1961.
	Pp. 92-96. Used by permission of Stephen Longstreet	0010-1710
Typographical Error: perfectability [1490]
2,029 words	40 (2.0%) quotes

K17. Leon Uris, Mila 8.
	New York: Doubleday &amp; Company, Inc., 1961. Pp. 324-329.
	Copyright  1961 by Leon Uris. Used by his permission.	0010-1770
2,008 words	826 (41.1%) quotes 1 symbol

K18. John Dos Passos, Midcentury.
	Boston: Houghton Mifflin Company, 1961. Pp. 94-98.
	Used by permission of John Dos Passos.	0020-1650
1,996 words	182 (9.1%) quotes

K19. Robert L. Duncan, The Voice of Strangers.
	Garden City, New York: Doubleday &amp; Company, Inc., 1961.
	Pp. 242-248. Used by permission of Robert L. Duncan.	0010-1710
Typographical Error: imagnation [0750]
2,063 words	279 (13.5%) quotes

K20. Guy Bolton, The Olympians.	
	Cleveland and New York: World Publishing Company, 1961. 
	Pp. 128-134. Used by permission of Guy Bolton.	0010-1760
2,012 words	478 (23.8%) quotes

K21. Bruce Palmer, "My Brother's Keeper", Many Are the Hearts.
	New York: Simon &amp; Schuster, Inc., 1961. Pp. 132-138.
	Used by permission of Bruce Palmer.		0010-1720
Note: No quotation marks are used in this text. Beginning of
	 quotation is marked by -; end of quotation by end of paragraph.
2,011 words	2 symbols

K22. John Cheever, "The Brigadier and the Golf Widow,"
	The New Yorker, 39 (November 11, 1961), 53-54.
	Used by permission of The New Yorker.		0010-1700
Arbitrary No Hyphen: birthcontrol [0520]
Note: locker room [0280] locker-room [0300]
2,018 words	377 (18.7%) quotes 1 symbol

K23. Frieda Arkin, "The Light of the Sea," in The Best American Short
	Stories 1962, edited by Martha Foley and David Burnett.
	Boston: Houghton Mifflin Company, 1961. Pp. 2-6.
	Used by permission of Frieda Arkin.		0010-1730
2,025 words	199 (9.8%) quotes

K24. W. H. Gass, "The Pedersen Kid," in The Best American Short Stories
	1962, edited by Martha Foley and David Burnett.
	Boston: Houghton Mifflin Company, 1962. Pp. 110-115.
	Used by permission of William H. Gass.	0010-1640
1,999 words	563 (28.2%) quotes

K25. Arthur Miller, "The Prophecy," in The Best American Short Stories
	1962, edited by Martha Foley and David Burnett.
	Boston: Houghton Mifflin Company, 1962. Pp. 258-262.
	Used by permission of Arthur Miller.		0010-1630
Typographical Error: Cycly [0380]
2,008 words	11 (0.5%) quotes

K26. Jane Gilmore Rushing, "Against the Moon," The Virginia Quarterly
	Review, 37: 3 (Summer, 1961), 378-383.
	Used by permission of Jane Gilmore Rushing and The Virginia
	Quarterly Review.			0010-1650
2,007 words	325 (16.2%) quotes 1 symbol

K27. E. Lucas Myers, "The Vindication of Dr. Nestor," The Sewanee
	Review, 69: 2 (Spring, 1961), 290-295.
	Used by permission of E. Lucas Myers and The Sewanee Review.	0010-1760
2,035 words	298 (14.6%) quotes

K28. Sallie Bingham, "Moving Day," The Atlantic Monthly, 208: 5 
	(November, 1961), 63-65.
	Used by permission of Sallie Bingham.		0010-1700
2,011 words	525 (26.1%) quotes

K29. Marvin Schiller, "The Sheep's in the Meadow," The Antioch
	Review, XXI: 3 (Fall, 1961), 336-340.
	Used by permission of The Antioch Review.	0010-1660
Typographical Error: gentlemen [for gentleman] [1340]
2,005 words	12 (0.6%) quotes 1 symbol
<hr><hr>

L: FICTION: MYSTERY


L01. Winfred Van Atta, Shock Treatment.
	Garden City, New York: Doubleday &amp; Company, Inc., 1961. Pp. 24-31.
	Used by permission of Winfred L. Van Atta. 	0010-1690
2,000 words	820 (41.0%) quotes

L02. A. A. Fair, Bachelors Get Lonely.
	New York: William Morrow &amp; Company, Inc., 1961. Pp. 82-89.
	Used by permission of William Morrow &amp; Company, Inc., 	0010-1700
Note: Automobile license JYJ 114 [0020] JYM 114 [0200]
2,024 words	478 (23.6%) quotes 2 symbols

L03. Amber Dean, Encounter with Evil.
	Garden City, New York: Doubleday &amp; Co., Inc., 1961. 
	Pp. 48-54. Used by permission of Amber Dean.	0010-1700
2,016 words	665 (33.0%) quotes

L04. David Alexander, Bloodstain.
	Philadelphia: J. B. Lippincott Co., 1961. Pp. 128-134
	Used by permission of David Alexander.	0010-1650
2,005 words	161 (8.0%) quotes

L05. Brett Halliday, The Careless Corpse.
	New York: Dodd, Mead and Co., 1961. Pp. 136-143.
	Used by permission of Brett Alexander.	0010-1730
Arbitrary Hyphens: knife-men [0350] palm-lined [0550]
Note: briefly-illumed [0640]
2,016 words	844 (41.9%) quotes 1 symbol

L06. Thomas B. Dewey, Hunter at Large.
	New York: Simon and Schuster, 1961. Pp. 118-124.
	Used by permission of Thomas B. Dewey.	0010-1630
2,015 words	31 (1.5%) quotes

L07. Genevieve Holden, Deadlier Than the Male.
	Garden City, New York: Doubleday &amp; Company, Inc., 1961.
	Pp. 96-104. Copyright  1961 by Doubleday &amp; Company, Inc.
	Used by their permission.			0010-1760
2,019 words	688 (34.1%) quotes

L08. Dell Shannon, The Ace of Spades.
	New York: William Morrow &amp; Company, Inc., 1961. Pp. 184-191.
	Used by permission of William Morrow &amp; Company, Inc.	0010-1750
2,034 words	708 (34.8%) quotes

L09. Mignon G. Eberhart, The Cup, the Blade or the Sword.
	New York: Random House, 1961. Pp. 126-132.
	Used by permission of Random House and M. G. Eberhart.	0010-1720
Arbitrary No Hyphen: homemade [0860]
2,027 words	313 (15.4%) quotes

L10. Harry Olesker, Impact.
	New York: Random House, 1961. Pp. 94-101.
	Used by permission of Harry Olesker.		0010-1830
Note: Question mark following Who? is Roman in 0740 and 0760,
	 otherwise italic.
2,005 words	235 (11.7%) quotes

L11. Hampton Stone, The Man Who Looked Death in the Eye.
	New York: Simon and Schuster, 1961. Pp. 56-62.
	Used by permission of Hampton Stone.		0010-1720
1,999 words	306 (15.3%) quotes 1 symbol

L12. Whit Masterson, Evil Come, Evil Go.
	New York: Pocket Books, Inc., 1961. Pp. 49-55.
	Used by permission of Dodd, Mead (original publisher)	0010-1810
1,998 words	555 (27.8%) quotes

L13. Dolores Hitchens, Footsteps in the Night.
	Garden City, New York: Doubleday &amp; Company, 1961. Pp. 156-161.
	Used by permission of Dolores Hitchens.	0010-1700
2.017 words	553 (27.4%) quotes

L14. Frances and Richard Lockridge, Murder Has Its Points.
	Philadelphia: J. B. Lippincott Company, 1961. Pp. 96-101.
	Used by permission of Richard Lockridge.	0010-1750
2,004 words	121 (6.0%) quotes 2 symbols

L15. Doris Miles Disney, Mrs. Meeker's Money.
	Garden City, New York: Doubleday &amp; Company, 1961. Pp. 72-78.
	Used by permission of Doris M. Disney.	0009-1800
Typographical Error: advise [for advice] [0940]
2,004 words	569 (28.4%) quotes

L16. Alex Gordon, The Cipher.
	New York: Simon and Schuster, 1961. Pp. 238-245.
	Used by permission of Alex Gordon.		0010-1730
2,016 words	387 (19.2%) quotes

L17. Breni James, Nights of the Kill.
	New York: Simon and Schuster, 1961. Pp. 114-122.
	Used by permission of Breni James.		0010-1790
2,000 words	588 (29.4%) quotes

L18. George Harmon Coxe, Error of Judgement.
	New York: Alfred A. Knopf, Inc., 1961. Pp. 24-29.
	Used by permission of Alfred A. Knopf, Inc.	0010-1640
2,005 words	337 (16.8%) quotes

L19. Brad Williams, Make a Killing.
	New York: M. S. Mill Company and William Morrow &amp; Company, 1961.
	Pp. 196-203. Used by permission of Brad Williams.	0010-1710
2,005 words	107 (5.3%) quotes 2 symbols

L20. Ed Lacy, "Death by the Numbers,' Manhunt, 9: 4 (August, 1961),
	8-12. Used by permission of Manhunt and Ed Lacy.	0010-1690
Arbitrary Hyphen: ocean-going [1480]
Typographical Error: apostrophe missing in Harbors [0610]
2,009 words	1058 (52.7%) quotes

L21. Helen McCloy, "The Black Disk," Ellery Queen's Mystery Magazine,
	37: 4 (April, 1961), 23-27.
	Used by permission of Helen McCloy.		0010-1810
Arbritrary Hyphen: spot-news [0270]
2,009 words	398 (19.8%) quotes

L22. S. L. M. Barlow, "Monologue of Murder," The Saint Mystery
	Magazine, 15: 2 (December, 1961), 121-125.
	Used by permission of The Saint Mystery Magazine.	0010-1640
Arbitrary Hyphen: free-holders [1210]
Typographical Error: buccolic [1350]
1,999 words	33 (1.7%) quotes

L23. J. W. Rose, "Try My Sample Murders," Trapped Detective Story
	Magazine, 6: 2 (November, 1961), 45-50.
	Used by permission of Trapped Detective Story Magazine.	0010-1680
Typographical Error: seeemd [0600]
2,013 words	357 (17.7%) quotes

L24. Fredric Brown, The Murderers.
	New York: E. P. Dutton &amp; Co., Inc., 1961. Pp. 116-122.
	Copyright  1961 by Fredric Brown. Reproduced by permission of
	E. P. Dutton &amp; Co., Inc.			0010-1680
Arbitrary Hyphen: show-down [1460]
2,052 words	782 (38.1%) quotes
<hr><hr>

M: FICTION: SCIENCE


M01. Robert Heinlein, Stranger in a Strange Land.
	New York: G. P. Putnam's Sons, 1961. Pp. 250-255.
	Used by permission of Robert A. Heinlein.	0010-1860
2,016 words	651 (32.3%) quotes 12 symbols

M02. Philip Jos&eacute; Farmer, The Lovers.
	New York: Ballantine Books, Inc., 1961. Pp. 37-42.
	Used by permission of Philip J. Farmer.	0010-1800
2,012 words	445 (22.1%) quotes

M03. James Blish, The Star Dwellers.
	New York: Avon Book Division, Hearst Corporation, 1961.
	Pp. 83-88. Used by permission of James Blish	0010-1730
Typographical Error: numenous [1150]
2,006 words	596 (29.7%) quotes 1 symbol

M04. Jim Harmon, "The Planet with No Nightmare," If, 11: 3 
	(July, 1961), 7-12. Used by permission of Jim Harmon.	0010-1820
Typographical Error: dispell [1210]
2,002 words	873 (43.6%) quotes 1 symbol

M05. Anne McCaffrey, "The Ship Who Sang," 7th Annual Edition The
	Year's Best S-F, edited by Judith Merril, pp. 311-317.
	Copyright  1961 by Anne McCaffrey. Reprinted from "The Magazine of
	FANTASY &amp; SCIENCE FICTION." Used by permission of Mercury Press,
	Inc.			0010-1900
Note: programed [1020]
2,006 words	297 (14.8%) quotes 1 symbol

M06. Cordwainer Smith, "A Planet Named Shayol," 7th Annual Edition
	The Year's Best S-F, edited by Judith Merril, pp. 353-358.
	Used by permission of Cordwainer Smith; originally published in
	Galaxy magazine.			0010-1740
Typographical Error: time [for times] [1110]
2,017 words	367 (18.2%) quotes
<hr><hr>

N: FICTION: ADVENTURE


N01. Wayne D. Overholser, The Killer Marshal.
	New York: Dell Publishing Co., 1963. [Copyright  1961]. Pp. 53-58.
	Used by permission of Wayne D. Overholser.	0010-1670
Note: blond hair [0560] blonde hair [0690]
2,004 words	561 (28.0%) quotes 2 symbols

N02. Clifford Irving, The Valley.
	New York: McGraw-Hill Book Company, Inc., 1961. Pp. 262-267.
	Used by permission of Clifford Irving.	0010-1660
2,017 words	620 (30.7%) quotes

N03. Cliff Farrell, Trail of the Tattered Star.
	Garden City, New York: Doubleday &amp; Company, Inc., 1961.
	Pp. 168-173. Copyright 1961 by Cliff Farrell.
	Used by his permission.			0010-1730
1,991 words	345 (17.3%) quotes

N04. James D. Horan, The Shadow Catcher.
	New York: Crown Publishers, Inc., 1961. Pp. 248-253.
	Used by permission of James D. Horan.		0010-1690
2,002 words 	984 (49.2%) quotes

N05. Richard Ferber, Bitter Valley.
	New York: Dell Publishing Company, 1961. Pp. 9-17.
	Used by permission of Richard W. Ferber.	0010-1670
Arbitrary Hyphens: dark-skinned [0600] broken-down [1220]
	              deep-set [0680]
2,016 words	501 (24.9%) quotes

N06. Thomas Anderson, Here Comes Pete Now.
	New York: Random House, 1961. Pp. 4-12.
	Used by permission of Thomas Anderson.	0010-1640
Typographical Error: of [for or] [0100]
2,017 words

N07. Todhunter Ballard, The Night Riders.
	New York: Pocket Books, Inc., 1961. Pp. 5-11.
	Used by permission of Todhunter Ballard.	0010-1790
2,014 words	499 (24.8%) quotes

N08. Mary Savage, Just for Tonight.
	New York: Dodd, Mead &amp; Company, 1961. Pp. 114-120.
	Used by permission of Mary Savage.		0010-1720
2,019 words	11 (0.5%) quotes

N09. Jim Thompson, The Transgressors.
	New York: The New American Library of World Literature.
	Inc., 1961. Pp. 9-13. Used by permission of Jim Thompson.	0010-1760
Typographical Error: ommission [0330]
2,012 words	483 (24.0%) quotes

N10. Joseph Chadwick, No Land Is Free.
	New York: Avon Book Division, Hearst Corporation, 1961.
	Pp. 21-26. Used by permission of Joseph L. Chadwick	0010-1760
Typographical Error: cossie's [for cookie's] [0080]
2,008 words	491 (24.5%) quotes

N11. Gene Caesar, Rifle for Rent.
	Derby, Connecticut: Monarch Books, Inc., 1963. Pp. 46-51.
	Used by permission of Gene Caesar. Copyright  1961.	0010-1740
2,017 words	296 (14.7%) quotes

N12. Edwin Booth, Outlaw Town.
	New York: Ballantine Books, Inc., 1961. Pp. 103-108.
	Used by permission of Edwin Booth.		0010-1750
Typographical Error: shout [for shot] [1220]
2,003 words	543 (27.1%) quotes

N13. Martha Ferguson McKeown, Mountains Ahead.
	New York: G. P. Putnam's Sons, 1961. Pp. 390-395.
	Used by permission of Martha Ferguson McKeown.	0010-1760
Arbitrary No Hyphen: ticklebrush [1380]
Note: Only used for However [0700]
2,016 words	479 (23.8%) quotes

N14. Peter Field, Rattlesnake Ridge.
	New York: Jefferson House, Inc., 1961. Pp. 164-172.
	Used by permission of William Morrow &amp; Company.	0010-1740
Typographical Errors: Unnecessary " [1110] down off [for off down ?] [1160]
	                 Auxiliary verb omitted [1600]
2,012 words	294 (14.6%) quotes

N15. Donald J. Plantz, Sweeney Squadron.
	New York: Dell Publishing Co., Inc., 1961. Pp. 133-138.
	Used by permission of original publisher, Doubleday &amp; Company,
	Inc.			0010-1700
	Typographical Error: targets of opportunities [0090]
2,016 words	159 (7.9%) quotes 2 symbols

N16. Ralph J. Salisbury, "On the Old Santa Fe Trail to Siberia,"
	Northwest Review, 4: 2 (Spring, 1961), 52-56
	Used by permission of Northwest Review.	0010-1840
Typographical Errors: Single close quote missing [0680]
	                 though [for thought] [1030]
2,031 words	258 (12.7%) quotes 1 symbol

N17. Richard S. Prather, "The Bawdy Beautiful," Cavalier, 11: 94
	(April, 1961), 64-65.
	Used by permission of Richard S. Prather.	0010-1770
2,011 words|	920 (45.7%) quotes 7 symbols

N18. Peter Bains, "With Women...Education Pays Off," Monsieur, 4: 2
	(February, 1961), 17, 77-78.
	Used by permission of Monsieur.		0010-1580
1,998 words	430 (21.5%) quotes

N19. David Jackson, "The English Gardens," Partisan Review, 28: 2
	(March-April, 1961), 216-221.
	Used by permission of Partisan Review &amp; David Jackson.	0010-1760
Typographical Error: with her hand poem again [1640]
2,055 words	389 (18.9%) quotes

N20. T. C. McClary, "The Flooded Desert," Argosy, 352: 4 (April, 1961)
	27, 104-106.
	Used by permission of Argosy.			0010-1720
2,016 words	327 (16.2%) quotes

N21. C. T. Sommers, "The Beautiful Mankillers of Eromonga,"
	Cavalcade (October, 1961), 60, 62.
	Used by permission of Cavalcade.		0010-1740
Typographical Error: Period missing [1400]
2,019 words	573 (28.4%) quotes

N22. Gordon Johnson, "A Matter of Curiosity," The Yale Review,
	L: 4 (June, 1961), 556-560.
	Used by permission of The Yale Review.	0010-1670
2,006 words	195 (9.7%) quotes 2 symbols

N23. Wheeler Hall, "Always Shoot to Kill," Bluebook for Men,
	100: 7 (October, 1961), 34-35, 52-53.
	Used by permission of Bluebook.		0010-1700
Arbitrary No Hyphen: tableland [0510] Hyphen: hand-holding [1140]
Typographical Errors: bicep [1090] WACS [for WACs or WAC's] [1110]
2,016 words	223 (11.1%) quotes 5 symbols

N24. T. K. Brown III, "The Fifteenth Station," Playboy, 8: 7
	(July, 1961), 36-38.
	Copyright  1961 by HMH Publishing Co., Inc. Used by permission.	0010-1750
2,005 words	963 (48.0%) quotes 3 symbols

N25. Wesley Newton, "Aid and Comfort to the Enemy," The
	University of Kansas City Review, 27: 3 (March, 1961), 210-213.
	Used by permission of The University of Kansas City Review.	0010-1780
	Arbitrary Hyphens: flame-throwers [0360] vine-crisscrossed [0490]
Typographical Error: packet [for jacket] [1710]
2,066 words	66 (3.2%) quotes

N26. Paul Brock, "Toughest Lawman in the Old West," Rage
	Magazine, 1: 4 (March, 1961), 41-43, 60.
	Used by permission of Rage Magazine.		0010-1780
Typographical Errors: collosal [0430] flng [for fling] [1490]
2,033 words	356 (17.5%) quotes

N27. James Hines and James Morris, "Just Any Girl" Swank, 8: 6
	(January, 1961), 37, 66-68.
	Used by permission of Swank.			0010-1720
Arbitrary Hyphens: middle-aged [0540] low-heeled [0960]
Typographical Errors: litle [0510] it [for is]  [1630] coud [1080]
2,027 words	377 (18.6%) quotes

N28. Ralph Grimshaw, "Mrs. Hacksaw: New Orleans' Society Killer,"
	Sir!, 18: 1 (September, 1961), 56-58.
	Used by permission of Sir!			0010-1800
Typographical Errors: for and calinda [0110] verict [1600]
	                 Period missing [0940]
2,017 words	429 (21.3%) quotes

N29. Harlan Ellison, "Riding the Dark Train Out," Rogue, 6: 5
	(May, 1961), 14, 30.
	Used by permission of Rogue.			0010-1820
Arbitrary Hyphens: freight-bums [0620] ever-lovin' [1080]
2,009 words	445 (22.2%) quotes
<hr><hr>

P.FICTION: ROMANCE


P01. Octavia Waldo, A Cup of the Sun.
	New York: Harcourt, Brace &amp; World, Inc., 1961. Pp. 8-14.
	Copyright  1961 by Octavia Waldo. Used by permission of
	Harcourt, Brace &amp; World, Inc.			0010-1700
2,034 words	116 (5.7%) quotes

P02. Ann Ritner, Seize a Nettle.
	Philadelphia: J. B. Lippincott Co., 1961. Pp. 158-162
	Used by permission of Fred B. Ritner.		0010-1710
Note: west [1030] West [1050]
Typographical Errors: at [for as] [1470] than [for then] [1590]
	                 Liliputian [0460]
2,028 words	610 (30.1%) quotes

P03. Clark McMeekin, The Fairbrothers.
	New York: G. P. Putnam's Sons, 1961. Pp. 258-264.
	Used by permission.			0010-1770
Note: "She would never be unable to resist" [0380]
Typographical Error: musn't [0870]
2,007 words	510 (25.4%) quotes

P04. B. J. Chute, The Moon and the Thorn.
	New York: E. P. Dutton &amp; Co., 1961. Pp. 34-41.
	Copyright  1961 by B. J. Chute. Used by permission of E. P.
	Dutton &amp; Co., Inc.			0010-1880
2,141 words	322 (15.0%) quotes

P05. Allen R. Bosworth, The Crows of Edwina Hill.
	New York: Harper &amp; Brothers, 1961. Pp. 26-31.
	Used by permission of Allan R. Bosworth.	0010-1740
2,008 words	118 (5.9%) quotes

P06. Richard Tiernan, "Land of the Silver Dollar," The Quixote
	Anthology, edited by Jean Rikhoff, Kam and Richard Tiernan.
	New York: Grosset's Universal Library, 1961. Pp. 36-40.
	Used by permission of Grosset &amp; Dunlap, Inc.	0010-1840
Typographical Error: Forebearing [0490]
2,052 words	859 (41.9%) quotes 2 symbols

P07. Vina Delmar, The Big Family.
	New York: Harcourt, Brace &amp; Co., 1961. Pp. 206-211.
	Used by permission of Vina Delmar.		0010-1780
2,007 words	728 (36.3%) quotes

P08. R. Leslie Gourse, With Gall and Honey.
	Garden City, New York: Doubleday &amp; Company, Inc., 1961. 
	Pp. 272-276. Used by permission of R. Leslie Gourse.	0010-1620
Typographical Error: a missing [1040]
2,001 words	918 (45.9%) quotes

P09. Jesse Hill Ford, Mountains of Gilead.
	Boston: Little, Brown &amp; Company, 1961. Pp. 128-133.
	Used by permission of Jesse Hill Ford.	0010-1530
1,991 words	74 (3.7.%) quotes

P10. Jay Williams, The Forger.
	New York: Atheneum, 1961. Pp. 4-8.
	Used by permission of Jay Williams.		0010-1710
2,022 words	722 (35.7%) quotes

P11. Bessie Breuer, Take Care of My Roses.
	New York: Atheneum, 1961. Pp. 168-176.
	Used by permission of Bessie Breuer.		0010-1660
2,025 words	253 (12.5%) quotes

P12. Morley Callaghan, A Passion in Rome.
	New York: Coward-McCann, Inc., 1961. Pp. 124-129
	Used by permission of Coward-McCann, Inc.	0010-1670
2,010 words	492 (24.5%) quotes

P13. Frank Borden Hanes, The Fleet Rabble.
	New York: L. C. Page Co., 1961. Pp. 40-44.
	Used by permission of Farrar, Straus &amp; Cudahy, Inc.	0010-1690
	Copyright  1961 by Frank Borden Hanes.
2,030 words	293 (14.4%) quotes

P14. Livingston Biddle, Jr., Sam Bentley's Island.
	New York: Doubleday &amp; Co., Inc., 1961. Pp. 70-75.
	Used by permission of Livingstone Biddle, Jr.	0010-1750
Arbitrary Hyphen: pinch-hit [1580] No Hyphen: cheekbones [0620]
2,023 words	584 (28.9%) quotes

P15. Loretta Burrough, "The Open Door," Good Housekeeping, 152: 5
	(May, 1961), 117-118. Used by permission of Good Housekeeping
	and Loretta Burrough.			0010-1760
Note: Gregg [0260] Greg [0340]
2,004 words	462 (23.1%) quotes

P16. Margery Finn Brown, "A Secret Between Friends," Redbook,
	116: 4 (February, 1961), 104-110.
	Used by permission of Redbook.			0010-1790
Typographical Errors: shouders [0630] encylopedia [1450]
2,001 words	639 (31.9%) quotes 3 symbols

P17. Al Hine, "The Huntress," Saturday Evening Post, February 4,
	1961, 29, 84-85.
	Used by permission of Al Hine.			0010-1720
2,009 words	233 (11.6%) quotes

P18. [Anonymous,] "No Room in My Heart to Forgive," Modern
	Romances, 56: 11 (November, 1961), 76-78.
	Used by permission of Modern Romances.	0010-1710
Arbitrary No Hyphen: cheekbones [0620]
Typographical Errors: televison [0820] come [for came] [1600]
2,010 words	654 (32.5%) quotes

P19. [Anonymous,] "This Cancer Victim May Ruin My Life," Medical
	Story, 1: 1 (September, 1961), 18-21, 36.
	Used by permission of Medical Story.		0010-1730
2,005 words	455 (22.7%) quotes 1 symbol

P20. Spencer Norris, "Dirty Dog Inn," The Dude, 6: 1 (September, 1961)
	9-10, 28-30.
	Used by permission of The Dude.		0010-1660
2,003 words	191 (9.5%) quotes 1 symbol

P21. Elizabeth Spencer, "The White Azalea," The Texas Quarterly,
	4: 4 (Winter, 1961), 112-115.
	Used by permission of The Texas Quarterly.	0010-1860
Arbitrary No Hyphen: lamplight [0200]
Typographical Error: real [for read] [1750]
2,160 words	271 (12.5%) quotes 2 symbols

P22. [Anonymous,] "A Husband Stealer from Way Back," True Love,
	76: 3 (October, 1961), 6-7, 12.
	Used by permission of True Love.		0010-1690
Typographical Error: 1 [for I] [0840]
2,031 words	243 (12.0%) quotes

P23. Barbara Robinson, "Something Very Much in Common," McCall's,
	88: 11 (August, 1961), 172-174.
	Used by permission of Barbara Robinson.	0010-1800
Typographical Error: Pyhrric [0440]
2,043 words	463 (22.7%) quotes

P24. Samuel Elkin, "The Ball Player," Nugget, 6: 5 (October, 1961)
	25-26, 31.
	Used by permission of Nugget.			0010-1830
Typographical Errors: quitely [for quietly] [0560]
	                 want [for wants] [1510]
2,004 words	642 (32.0%) quotes

P25. William Butler, "The Pool at Ryusenji," Harper's Bazaar, 94th
	year, no. 2990 (January, 1961), 146-147.
	Used by permission of Harper's Bazaar.	0010-1710
Arbitrary Hyphen: by-ways [0020] No Hyphen: today [0740]
2,021 words	287 (14.2%) quotes

P26. Ervin D. Krause, "The Snake," Prize Stories 1963: The O. Henry
	Awards. New York: Doubleday &amp; Company, 1963. First published
	in Prairie Schooner, Summer, 1961.
	Used by permission of Ervin D. Krause.	0010-1590
Arbitrary Hyphen: jet-black [0340] No Hyphen: plowshares [0660]
2,017 words	177 (8.8%) quotes

P27. Lee McGiffin, "Measure of a Man," Ladies' Home Journal, 78: 6
	(June, 1961), 103-104.
	Used by permission of Ladies' Home Journal.	0010-1810
2,008 words	766 (38.1%) quotes 3 symbols

P28. Carol Hoover, "The Shorts on the Bedroom Floor," Story,
	XXXIV: 133 (February, 1961), 38-42.
	Used by permission of Story.			0010-1700
2,027 words	65 (3.2%) quotes

P29. Robert Carson, My Hero.
	New York: McGraw-Hill Book Company, 1961. Pp. 170-174.
	Used by permission of McGraw-Hill Book Company.	0010-1910
2,001 words	926 (46.3%) quotes 12 symbols
<hr><hr>

R. HUMOR


R01. Anita Loos, No Mother to Guide Her.
	New York: McGraw-Hill Book Company, 1961. Pp. 108-115.
	Used by permission of Anita Loos.		0010-1750
Typographical Error: quibs [for quips] [0780]
2,011 words	110 (5.5%) quotes

R02. Jean Mercier, Whatever You Do, Don't Panic.
	New York: Doubleday &amp; Company, Inc., 1961. Pp. 28-35.
	Used by permission of Doubleday &amp; Company, Inc.	0010-1780
2,020 words	101 (5.0%) quotes 2 symbols

R03. Patrick Dennis, Little Me.
	New York: E. P. Dutton &amp; Co., Inc., 1961.
	Copyright  1961 by Lancelot Leopard, Inc.
	Used by permission of E. P. Dutton &amp; Co., Inc.	0010-1920
Typographical Error: governmen [0520]
2,152 words	248 (11.5%) quotes 4 symbols

R04. Edward Streeter, The Chairman of the Bored.
	New York: Harper &amp; Brothers, 1961. Pp. 220-226.
	Used by permission of Edward Streeter.	0010-1670
Note: babbiting [0640]
2,006 words	225 (11.2%) quotes 1 symbol

R05. Evan Esar, Humorous English; a guide to comic usage,
	jocular speech and writing, and witty grammar.
	New York: Horizon Press, 1961. Pp. 141-148.
	Used by permission of Evan Esar.		0010-1850
Typographical Error: indefinity [1400]
Arbitrary Hyphen: girl-friend [0230] No Hyphen: standby [0500]
2,024 words	839 (41.5%) quotes 1 formula

R06. James Thurber, "The Future, If Any, of Comedy," Harper's 
	Magazine 223: 1339 (December, 1961), 40-43.
	Used by permission of Mrs. James Thurber.	0010-1780
2,015 words	1,646 (81.7%) quotes					 

R07. John Hazard Wildman, "Take It Off," The Arizona Quarterly, 17: 3,
	(Autumn, 1961), 246-252.
	Used by permission of The Arizona Quarterly.	0010-1770
2,028 words	356 (17.6%) quotes

R08. Leo Lemon, "Catch Up With" and "Something to Talk About," 
	Mademoiselle, July, 1961, 8, 15, 17, 47-49.
	Used by permission of Mademoiselle.		0010-1910
Arbitrary Hyphens: tongue-twister [0380] biri-pitknoumen [0390]
Note: F-major [0860] N minor [0870]
Typographical Error: unwaivering [1810]
2,027 words	118 (5.8%) quotes 5 symbols

R09.  S. J. Perelman, The Rising Gorge. New York: Simon and
	Schuster, 1961. Used by permission of S. J. Perelman.
	Pp. 201-207.			0010-1740
2,004 words	47 (2.3%) quotes 1 symbol

